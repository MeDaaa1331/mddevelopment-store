Config = {}
Config.Debug = false

Config.Blip = {
    Sprite = 351,
    Color = 0,
    Scale = 0.8,
    Label = 'Centrum Brigad'
}

Config.MainPed = {
    model = 'a_m_y_business_02',
    coords = vector4(-552.4881, -202.8239, 37.2390, 315.7231),
    label = 'Centrum Brigád'
}

Config.Jobs = {
    ['gardener'] = {
        label = 'Zahradník',
        description = 'Úprava zeleně ve městě. Fyzicky náročná, ale klidná práce.',
        icon = 'fa-solid fa-leaf',
        
        pedCoords = vector4(-1099.0789, -256.8496, 37.6875, 150.7969),
        vehicle = 'bison',
        payoutMin = 100,
        payoutMax = 200,
        locations = {
            vector3(-1110.8722, -194.1343, 38.0544),
            vector3(-1061.7964, -158.7456, 37.8298),
            vector3(-1029.6736, -154.4778, 38.1878),
            vector3(-924.3093, -106.3406, 37.9212),
            vector3(-849.7279, -66.7184, 37.8384),
            vector3(-784.5980, -40.1279, 38.7486),
            vector3(-669.5178, -22.9000, 38.6237),
            vector3(-691.7061, 15.2545, 38.3901),
            vector3(-689.7103, 271.8490, 81.5201),
            vector3(-488.2466, 232.2008, 83.0076),
            vector3(-313.5713, 171.7730, 88.9029),
            vector3(-805.4664, 293.4322, 86.1197),
            vector3(-865.7557, 260.9725, 77.3125),
            vector3(-953.4100, 290.8050, 69.8878),
            vector3(-993.4054, 391.2776, 73.5495),
            vector3(-1376.2456, 52.9432, 53.8620),
            vector3(-1652.6122, -271.7336, 52.8356),
        }
    },

    ['poolcleaner'] = {
        label = 'Čistič bazénů',
        description = 'Čistění bazénů. Práce v bohaté čtvrti Los Santos!',
        icon = 'fa-solid fa-broom',
        
        pedCoords = vector4(-1099.0789, -256.8496, 37.6875, 150.7969),
        vehicle = 'speedo',
        payoutMin = 120,
        payoutMax = 210,
        locations = {
            vector3(-740.1965, 782.5051, 213.2863),
            vector3(-674.9769, 799.0316, 199.0002),
            vector3(-863.3699, 763.3875, 191.4567),
            vector3(-906.1218, 741.5330, 181.7899),
            vector3(-1023.2155, 761.9200, 171.2087),
            vector3(-1066.5060, 827.8552, 166.4542),
            vector3(-1062.6436, 579.3049, 102.9524),
            vector3(-1171.5392, 600.9108, 103.0472),
            vector3(-1299.3240, 479.6089, 97.6580),
            vector3(-1063.7970, 502.1947, 85.6723),
            vector3(-1013.0511, 530.5127, 79.6220),
            vector3(-943.3983, 503.8298, 81.6714),
            vector3(-886.7600, 321.8869, 83.8782),
            vector3(-182.9258, 565.8864, 189.7702),
            vector3(-234.4293, 569.7975, 185.2930),
            vector3(-322.0131, 601.9149, 172.4451),
        }
    },

    ['locksmith'] = {
        label = 'Zámečník',
        description = 'Zámečnické zakázky. Pomáhej lidem se dostat zpět do svých domovů!',
        icon = 'fa-solid fa-lock',
        
        pedCoords = vector4(-1099.0789, -256.8496, 37.6875, 150.7969),
        vehicle = 'sadler',
        payoutMin = 190,
        payoutMax = 300,
        locations = {
            vector3(279.8782, -2043.5842, 19.7675),
            vector3(290.1691, -2031.2190, 19.7676),
            vector3(311.8906, -1956.2024, 24.6119),
            vector3(250.8755, -1934.9609, 24.7055),
            vector3(405.7781, -1751.1777, 29.7101),
            vector3(430.2433, -1559.5406, 32.8120),
            vector3(185.2879, -1077.8052, 29.2745),
            vector3(-232.3508, -915.6183, 32.3108),
            vector3(-670.5175, -888.8901, 24.4991),
            vector3(-747.3234, 808.3204, 215.0306),
            vector3(-931.9861, 809.1343, 184.7792),
            vector3(-1100.6653, 797.8900, 167.2379),
            vector3(-1130.8986, 784.4147, 163.8877),
            vector3(-166.1891, 424.0628, 111.8058),
            vector3(-66.4857, 489.9242, 144.8756),
            vector3(-189.6524, 618.3561, 199.6482),
            vector3(-340.3129, 668.5305, 172.7842),
        }
    },

    ['trucker'] = {
        label = 'Kamioňák',
        description = 'Rozvážej zboží po celém San Andreas.',
        icon = 'fa-solid fa-truck',
        payoutMin = 400,
        payoutMax = 700,
        
        pedCoords = vector4(-529.0196, -271.2605, 35.1874, 109.7276),
        
        truckModel = 'phantom',
        trailerModel = 'trailers2',
        
        Spawn = {
            phantom = vector4(-529.0196, -271.2605, 35.1874, 109.7276),
            trailer = vector4(-504.8448, -261.3723, 35.4966, 112.3689)
        },

        locations = {
            [1] = {
                label = 'Paleto Bay',
                money = 700,
                kdeodevzdas = vector4(119.4688, 6417.6484, 31.3686, 37.1720)
            },
            [2] = {
                label = 'Sandy Shores Ammu',
                money = 500,
                kdeodevzdas = vector4(1701.9794, 3767.0803, 34.4480, 45.8757)
            },
            [3] = {
                label = 'Přístav Los Santos',
                money = 400,
                kdeodevzdas = vector4(110.6728, -2993.9304, 6.0000, 179.7170)
            },
            [4] = {
                label = 'Industriální zona',
                money = 400,
                kdeodevzdas = vector4(1093.5255, -2298.7695, 30.1177, 171.3160)
            },
            [5] = {
                label = 'Obchod GOH',
                money = 400,
                kdeodevzdas = vector4(-3146.4736, 1106.5269, 20.7052, 338.7045)
            },
        }
    },

    ['taxi'] = {
        label = 'Taxikář',
        description = 'Rozvážej zákazníky po celém městě!',
        icon = 'fa-solid fa-taxi',
        payoutMin = 180,
        payoutMax = 400,

        pedCoords = vector4(-529.0196, -271.2605, 35.1874, 109.7276), 
        vehicle = 'taxi',
        
        locations = {
            [1] = {
                pay = 270,
                pickup = {
                    npc = vector4(295.4894, -590.6263, 43.2509, 72.2717),
                    vehicle = vector4(293.2806, -589.9008, 43.1363, 350.6057)
                },
                dropoff = {
                    vehicle = vector4(322.0342, 319.5763, 105.2872, 254.9292)
                }
            },
            [2] = {
                pay = 320,
                pickup = {
                    npc = vector4(-207.1309, 1054.9237, 234.1066, 171.9862),
                    vehicle = vector4(-208.0238, 1051.5963, 234.1993, 167.9522)
                },
                dropoff = {
                    vehicle = vector4(-1628.2930, -272.5228, 52.6090, 165.5972)
                }
            },
            [3] = {
                pay = 180,
                pickup = {
                    npc = vector4(139.9471, -1299.8439, 29.2086, 210.6954),
                    vehicle = vector4(141.1240, -1301.7911, 29.1228, 212.0252)
                },
                dropoff = {
                    vehicle = vector4(262.6785, -615.3044, 42.2552, 65.0047)
                }
            },
            [4] = {
                pay = 400,
                pickup = {
                    npc = vector4(182.0650, -1010.5955, 29.3241, 170.2076),
                    vehicle = vector4(184.8907, -1014.7531, 29.2502, 80.5859)
                },
                dropoff = {
                    vehicle = vector4(-3241.4050, 989.1485, 12.4776, 151.3090)
                }
            },
            [5] = {
                pay = 270,
                pickup = {
                    npc = vector4(-2186.3716, -368.7152, 13.0659, 261.1617),
                    vehicle = vector4(-2183.9233, -369.8879, 13.0815, 229.9611)
                },
                dropoff = {
                    vehicle = vector4(2.5637, -151.1490, 56.1740, 246.1674)
                }
            },
        }
    },
}