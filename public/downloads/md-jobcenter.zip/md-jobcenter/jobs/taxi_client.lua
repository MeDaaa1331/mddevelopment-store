local onDuty = false
local currentBlip = nil
local spawnedVehicle = nil
local customerPed = nil
local isPickingUp = false
local isDroppingOff = false
local remainingRoutes = {}
local JobConfig = Config.Jobs['taxi']

RegisterNetEvent('md-jobmenu:taxi:start', function()
    if onDuty then return end
    onDuty = true
    
    remainingRoutes = {}
    for k, v in pairs(JobConfig.locations) do 
        table.insert(remainingRoutes, v) 
    end
    
    lib.notify({title = 'Taxi', description = 'Směna **zahájena!** Vyzvedni si auto a čekej na zákazníky.', type = 'info', duration = 7000})
    NextTaxiJob()
end)

RegisterNetEvent('md-jobmenu:taxi:stop', function()
    if not onDuty then return end
    onDuty = false
    isPickingUp = false
    isDroppingOff = false
    
    if currentBlip then RemoveBlip(currentBlip) end
    lib.hideTextUI()
    
    if DoesEntityExist(customerPed) then DeleteEntity(customerPed) customerPed = nil end
    if DoesEntityExist(spawnedVehicle) then DeleteEntity(spawnedVehicle) spawnedVehicle = nil end

    lib.notify({title = 'Taxi', description = 'Směna **ukončena.**', type = 'info'})
end)

RegisterNetEvent('md-jobmenu:taxi:vehicle', function()
    if DoesEntityExist(spawnedVehicle) then
        lib.notify({type = 'error', description = 'Vozidlo už máš **vytažené!**'})
    else
        ESX.Game.SpawnVehicle(JobConfig.vehicle, JobConfig.pedCoords, JobConfig.pedCoords.w, function(vehicle)
            spawnedVehicle = vehicle
            TaskWarpPedIntoVehicle(cache.ped, vehicle, -1)
            lib.notify({type = 'success', description = 'Taxík **přistaven.**'})
        end)
    end
end)

function NextTaxiJob()
    if not onDuty then return end

    if #remainingRoutes == 0 then
        lib.notify({title = 'Hotovo', description = 'Všichni zákazníci rozvezeni! **Vrať se na centrálu.**', type = 'success', duration = 7000})
        return
    end

    local randomIndex = math.random(1, #remainingRoutes)
    local route = remainingRoutes[randomIndex]
    table.remove(remainingRoutes, randomIndex)

    lib.requestModel('a_m_m_business_01')
    customerPed = CreatePed(0, 'a_m_m_business_01', route.pickup.npc.xyz, route.pickup.npc.w, true, true)
    FreezeEntityPosition(customerPed, true)
    SetBlockingOfNonTemporaryEvents(customerPed, true)
    SetEntityInvincible(customerPed, true)

    local pickupCoords = route.pickup.vehicle.xyz

    currentBlip = AddBlipForCoord(pickupCoords)
    SetBlipSprite(currentBlip, 280)
    SetBlipColour(currentBlip, 5)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Zákazník")
    EndTextCommandSetBlipName(currentBlip)

    lib.notify({title = 'Dispečink', description = 'Máš nového zákazníka. Dojeď ho vyzvednout.', type = 'inform'})

    isPickingUp = true

    CreateThread(function()
        local textShown = false
        local isBusy = false
        
        while isPickingUp do
            Wait(0)
            if not isBusy then
                local pedCoords = GetEntityCoords(cache.ped)
                local dist = #(pedCoords - pickupCoords)

                if dist < 50.0 then
                    DrawMarker(1, pickupCoords.x, pickupCoords.y, pickupCoords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.0, 3.0, 1.0, 100, 180, 255, 120, false, true, 2, false, nil, nil, false)
                    
                    if dist < 4.0 and IsPedInAnyVehicle(cache.ped, false) then
                        if not textShown then
                            lib.showTextUI('[E] - Naložit zákazníka')
                            textShown = true
                        end

                        if IsControlJustReleased(0, 38) then
                            isBusy = true
                            if textShown then
                                lib.hideTextUI()
                                textShown = false
                            end

                            if currentBlip then RemoveBlip(currentBlip) end

                            FreezeEntityPosition(customerPed, false)
                            TaskEnterVehicle(customerPed, spawnedVehicle, -1, 2, 1.0, 1, 0)
                            
                            lib.notify({title = 'Taxi', description = 'Zákazník nastupuje, počkej chvíli.', type = 'info'})
                            Wait(4000)

                            isPickingUp = false
                            StartDropoffPhase(route)
                        end
                    else
                        if textShown then
                            lib.hideTextUI()
                            textShown = false
                        end
                    end
                else
                    Wait(500)
                end
            end
        end
        
        if textShown then lib.hideTextUI() end
    end)
end

function StartDropoffPhase(route)
    local dropCoords = route.dropoff.vehicle.xyz

    currentBlip = AddBlipForCoord(dropCoords)
    SetBlipSprite(currentBlip, 280)
    SetBlipColour(currentBlip, 2)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Cíl cesty")
    EndTextCommandSetBlipName(currentBlip)

    lib.notify({title = 'Dispečink', description = 'Odvez zákazníka na místo určení.', type = 'inform'})

    isDroppingOff = true

    CreateThread(function()
        local textShown = false
        local isBusy = false
        
        while isDroppingOff do
            Wait(0)
            if not isBusy then
                local pedCoords = GetEntityCoords(cache.ped)
                local dist = #(pedCoords - dropCoords)

                if dist < 50.0 then
                    DrawMarker(1, dropCoords.x, dropCoords.y, dropCoords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.0, 3.0, 1.0, 100, 180, 255, 120, false, true, 2, false, nil, nil, false)
                    
                    if dist < 4.0 and IsPedInAnyVehicle(cache.ped, false) then
                        if not textShown then
                            lib.showTextUI('[E] - Vysadit zákazníka')
                            textShown = true
                        end

                        if IsControlJustReleased(0, 38) then
                            isBusy = true
                            if textShown then
                                lib.hideTextUI()
                                textShown = false
                            end

                            if currentBlip then RemoveBlip(currentBlip) end

                            TaskLeaveVehicle(customerPed, spawnedVehicle, 0)
                            lib.notify({title = 'Taxi', description = 'Zákazník vystupuje...', type = 'info'})
                            Wait(3000)

                            DeleteEntity(customerPed)
                            customerPed = nil

                            TriggerServerEvent('md-jobmenu:addPayout', route.pay)
                            lib.notify({title = 'Taxi', description = 'Zákazník zaplatil. Čekej na další rito.', type = 'success'})
                            
                            isDroppingOff = false
                            Wait(2000)
                            NextTaxiJob()
                        end
                    else
                        if textShown then
                            lib.hideTextUI()
                            textShown = false
                        end
                    end
                else
                    Wait(500)
                end
            end
        end
        
        if textShown then lib.hideTextUI() end
    end)
end