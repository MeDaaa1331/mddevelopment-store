local onDuty = false
local currentBlip = nil
local spawnedTruck = nil
local spawnedTrailer = nil
local isDelivering = false
local remainingRoutes = {}
local JobConfig = Config.Jobs['trucker']

RegisterNetEvent('md-jobmenu:trucker:start', function()
    if onDuty then return end
    onDuty = true
    
    remainingRoutes = {}
    for k, v in pairs(JobConfig.locations) do 
        table.insert(remainingRoutes, v) 
    end
    
    lib.notify({title = 'Kamioňák', description = 'Směna **zahájena!** Vytáhni si soupravu.', type = 'info', duration = 7000})
    NextTruckRoute()
end)

RegisterNetEvent('md-jobmenu:trucker:stop', function()
    if not onDuty then return end
    onDuty = false
    isDelivering = false 
    
    if currentBlip then RemoveBlip(currentBlip) end
    lib.hideTextUI() 
    
    if DoesEntityExist(spawnedTruck) then DeleteEntity(spawnedTruck) spawnedTruck = nil end
    if DoesEntityExist(spawnedTrailer) then DeleteEntity(spawnedTrailer) spawnedTrailer = nil end

    lib.notify({title = 'Kamioňák', description = 'Směna **ukončena.**', type = 'info'})
end)

RegisterNetEvent('md-jobmenu:trucker:vehicle', function()
    if DoesEntityExist(spawnedTruck) then
        lib.notify({type = 'error', description = 'Soupravu už máš **vytaženou!**'})
    else
        if IsAnyVehicleNearPoint(JobConfig.Spawn.phantom.x, JobConfig.Spawn.phantom.y, JobConfig.Spawn.phantom.z, 6.0) then
            lib.notify({type = 'error', description = 'Místo pro spawn je obsazené!'})
            return
        end

        lib.requestModel(JobConfig.truckModel)
        lib.requestModel(JobConfig.trailerModel)

        spawnedTruck = CreateVehicle(JobConfig.truckModel, JobConfig.Spawn.phantom.x, JobConfig.Spawn.phantom.y, JobConfig.Spawn.phantom.z, JobConfig.Spawn.phantom.w, true, false)
        spawnedTrailer = CreateVehicle(JobConfig.trailerModel, JobConfig.Spawn.trailer.x, JobConfig.Spawn.trailer.y, JobConfig.Spawn.trailer.z, JobConfig.Spawn.trailer.w, true, false)

        SetVehicleOnGroundProperly(spawnedTruck)
        SetVehicleOnGroundProperly(spawnedTrailer)
        TaskWarpPedIntoVehicle(cache.ped, spawnedTruck, -1)

        lib.notify({type = 'success', description = 'Souprava **přistavena.** Můžeš vyrazit.'})
    end
end)

function NextTruckRoute()
    if not onDuty then return end

    if #remainingRoutes == 0 then
        lib.notify({title = 'Hotovo', description = 'Všechny trasy dokončeny! **Vrať se na depo a ukonči směnu.**', type = 'success', duration = 7000})
        isDelivering = false
        if currentBlip then RemoveBlip(currentBlip) end
        return
    end

    local randomIndex = math.random(1, #remainingRoutes)
    local route = remainingRoutes[randomIndex]
    table.remove(remainingRoutes, randomIndex)

    local dropCoords = route.kdeodevzdas.xyz

    currentBlip = AddBlipForCoord(dropCoords)
    SetBlipSprite(currentBlip, 477)
    SetBlipColour(currentBlip, 3)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Místo vykládky")
    EndTextCommandSetBlipName(currentBlip)

    lib.notify({title = 'Dispečink', description = 'Zajeď do ' .. route.label .. ' a vylož zboží.', type = 'inform'})

    isDelivering = true
    
    CreateThread(function()
        local textShown = false
        local isBusy = false
        
        while isDelivering do
            Wait(0)
            if not isBusy then
                local pedCoords = GetEntityCoords(cache.ped)
                local dist = #(pedCoords - dropCoords)

                if dist < 50.0 then
                    DrawMarker(1, dropCoords.x, dropCoords.y, dropCoords.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 6.0, 6.0, 2.0, 100, 180, 255, 120, false, true, 2, false, nil, nil, false)
                    
                    if dist < 4.0 then
                        if not textShown then
                            lib.showTextUI('[E] - Odevzdat zboží')
                            textShown = true
                        end

                        if IsControlJustReleased(0, 38) then
                            isBusy = true
                            if textShown then
                                lib.hideTextUI()
                                textShown = false
                            end

                            local ok = lib.progressBar({
                                duration = 5000,
                                label = 'Probíhá vykládka...',
                                canCancel = false,
                                disable = { move = true, combat = true, car = true }
                            })

                            if ok then
                                isDelivering = false
                                if currentBlip then RemoveBlip(currentBlip) end

                                TriggerServerEvent('md-jobmenu:addPayout', route.money)
                                lib.notify({title = 'Hotovo', description = 'Zboží odevzdáno. Dispečink ti hledá další zakázku...', type = 'success'})
                                
                                Wait(2000)
                                NextTruckRoute()
                            else
                                isBusy = false
                            end
                        end
                    else
                        if textShown then
                            lib.hideTextUI()
                            textShown = false
                        end
                    end
                else
                    Wait(500)
                end
            end
        end
        
        if textShown then lib.hideTextUI() end
    end)
end