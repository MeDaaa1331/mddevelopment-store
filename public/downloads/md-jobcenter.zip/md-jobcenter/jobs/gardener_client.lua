local onDuty = false
local currentBlip = nil
local spawnedVehicle = nil
local remainingLocations = {}
local currentZoneId = nil
local JobConfig = Config.Jobs['gardener']

RegisterNetEvent('md-jobmenu:gardener:start', function()
    if onDuty then return end
    onDuty = true
    
    if currentZoneId then exports.ox_target:removeZone(currentZoneId) end
    if currentBlip then RemoveBlip(currentBlip) end
    
    lib.notify({title = 'Zahradník', description = 'Směna **zahájena!** Vezmi si auto a jeď na první zakázku.', type = 'info', duration = 7000})
    
    StartGardenerLoop()
end)

RegisterNetEvent('md-jobmenu:gardener:stop', function()
    if not onDuty then return end
    onDuty = false
    
    if currentBlip then RemoveBlip(currentBlip) end
    if currentZoneId then exports.ox_target:removeZone(currentZoneId) currentZoneId = nil end
    
    if DoesEntityExist(spawnedVehicle) then
        DeleteEntity(spawnedVehicle)
        spawnedVehicle = nil
    end

    lib.notify({title = 'Zahradník', description = 'Směna **ukončena!**', type = 'info'})
end)

RegisterNetEvent('md-jobmenu:gardener:vehicle', function()
    if DoesEntityExist(spawnedVehicle) then
        lib.notify({type = 'error', description = '**Vozidlo už máš vytažené!**'})
    else
        ESX.Game.SpawnVehicle(JobConfig.vehicle, JobConfig.pedCoords, JobConfig.pedCoords.w, function(vehicle)
            spawnedVehicle = vehicle
            TaskWarpPedIntoVehicle(cache.ped, vehicle, -1)
            lib.notify({type = 'success', description = '**Vozidlo přistaveno!**'})
        end)
    end
end)

function StartGardenerLoop()
    remainingLocations = {table.unpack(JobConfig.locations)}
    NextGardenerJob()
end

function NextGardenerJob()
    if not onDuty then return end

    if currentZoneId then 
        exports.ox_target:removeZone(currentZoneId)
        currentZoneId = nil 
    end
    if currentBlip then RemoveBlip(currentBlip) end

    if #remainingLocations == 0 then
        lib.notify({title = 'Hotovo', description = '**Všechny lokace hotovy! Vrať se na depo pro novou směnu.**', type = 'success', duration = 7000})
        return
    end

    local randomIndex = math.random(1, #remainingLocations)
    local loc = remainingLocations[randomIndex]

    table.remove(remainingLocations, randomIndex)

    currentBlip = AddBlipForCoord(loc)
    SetBlipSprite(currentBlip, 1)
    SetBlipColour(currentBlip, 2)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Zakazka")
    EndTextCommandSetBlipName(currentBlip)

    currentZoneId = 'gardener_zone_' .. math.random(100000, 999999)

    exports.ox_target:addSphereZone({
        name = currentZoneId,
        coords = loc,
        radius = 2.0,
        debug = Config.Debug,
        options = {
            {
                name = 'gardener_work',
                icon = 'fa-solid fa-leaf',
                label = 'Upravit zeleň',
                onSelect = function()
                    if lib.progressBar({
                        duration = 15000,
                        label = 'Upravuješ zeleň...',
                        useWhileDead = false,
                        canCancel = false,
                        disable = {
                            car = true,
                            move = true,
                            combat = true
                        },
                        anim = {
                            scenario = 'WORLD_HUMAN_GARDENER_PLANT'
                        },
                    }) then

                        local reward = math.random(JobConfig.payoutMin, JobConfig.payoutMax)
                        TriggerServerEvent('md-jobmenu:addPayout', reward)
                        
                        if currentZoneId then
                            exports.ox_target:removeZone(currentZoneId)
                            currentZoneId = nil
                        end

                        if currentBlip then RemoveBlip(currentBlip) end

                        Wait(500)
                        NextGardenerJob()
                    else
                        lib.notify({type = 'error', description = 'Práce přerušena.'})
                    end
                end
            }
        }
    })
end