local onDuty = false
local currentBlip = nil
local spawnedVehicle = nil
local remainingLocations = {}
local currentZoneId = nil
local JobConfig = Config.Jobs['locksmith']

RegisterNetEvent('md-jobmenu:locksmith:start', function()
    if onDuty then return end
    onDuty = true
    
    if currentZoneId then exports.ox_target:removeZone(currentZoneId) end
    if currentBlip then RemoveBlip(currentBlip) end
    
    lib.notify({title = 'Zámečník', description = 'Směna **zahájena!** Dojeď na vyznačené lokace.', type = 'info', duration = 7000})
    
    StartLocksmithLoop()
end)

RegisterNetEvent('md-jobmenu:locksmith:stop', function()
    if not onDuty then return end
    onDuty = false
    
    if currentBlip then RemoveBlip(currentBlip) end
    if currentZoneId then exports.ox_target:removeZone(currentZoneId) currentZoneId = nil end
    
    if DoesEntityExist(spawnedVehicle) then
        DeleteEntity(spawnedVehicle)
        spawnedVehicle = nil
    end

    lib.notify({title = 'Zámečník', description = 'Směna **ukončena.**', type = 'info'})
end)

RegisterNetEvent('md-jobmenu:locksmith:vehicle', function()
    if DoesEntityExist(spawnedVehicle) then
        lib.notify({type = 'error', description = 'Vozidlo už máš **vytažené!**'})
    else
        ESX.Game.SpawnVehicle(JobConfig.vehicle, JobConfig.pedCoords, JobConfig.pedCoords.w, function(vehicle)
            spawnedVehicle = vehicle
            TaskWarpPedIntoVehicle(cache.ped, vehicle, -1)
            lib.notify({type = 'success', description = 'Vozidlo **přistaveno.**'})
        end)
    end
end)

function StartLocksmithLoop()
    remainingLocations = {table.unpack(JobConfig.locations)}
    NextLocksmithJob()
end

function NextLocksmithJob()
    if not onDuty then return end

    if currentZoneId then 
        exports.ox_target:removeZone(currentZoneId)
        currentZoneId = nil 
    end
    if currentBlip then RemoveBlip(currentBlip) end

    if #remainingLocations == 0 then
        lib.notify({title = 'Hotovo', description = 'Všechny zakázky dokončeny! **Vrať se na depo.**', type = 'success', duration = 7000})
        return
    end

    local randomIndex = math.random(1, #remainingLocations)
    local loc = remainingLocations[randomIndex]
    
    table.remove(remainingLocations, randomIndex)

    currentBlip = AddBlipForCoord(loc)
    SetBlipSprite(currentBlip, 1)
    SetBlipColour(currentBlip, 3)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Zakazka")
    EndTextCommandSetBlipName(currentBlip)

    currentZoneId = 'locksmith_zone_' .. math.random(100000, 999999)

    exports.ox_target:addSphereZone({
        name = currentZoneId,
        coords = loc,
        radius = 1.5,
        debug = Config.Debug,
        options = {
            {
                name = 'locksmith_work',
                icon = 'fa-solid fa-key',
                label = 'Vypáčit zámek',
                onSelect = function()
                    local dict = 'mp_arresting'
                    local anim = 'a_uncuff'
                    
                    lib.requestAnimDict(dict)
                    TaskPlayAnim(cache.ped, dict, anim, 8.0, 8.0, -1, 1, 0, false, false, false)

                    local success = exports['lockpick']:startLockpick(2)

                    ClearPedTasks(cache.ped)

                    if success then
                        local reward = math.random(JobConfig.payoutMin, JobConfig.payoutMax)
                        TriggerServerEvent('md-jobmenu:addPayout', reward)

                        if currentZoneId then
                            exports.ox_target:removeZone(currentZoneId)
                            currentZoneId = nil
                        end
                        if currentBlip then RemoveBlip(currentBlip) end

                        Wait(1000)
                        NextLocksmithJob()
                    else

                        lib.notify({type = 'error', description = '**Nepodařilo** se ti vypáčit zámek. Zkus to znovu.'})
                    end
                end
            }
        }
    })
end