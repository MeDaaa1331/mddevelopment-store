local onDuty = false
local currentBlip = nil
local spawnedVehicle = nil
local remainingLocations = {}
local currentZoneId = nil
local JobConfig = Config.Jobs['poolcleaner']

RegisterNetEvent('md-jobmenu:poolcleaner:start', function()
    if onDuty then return end
    onDuty = true
    
    if currentZoneId then exports.ox_target:removeZone(currentZoneId) end
    if currentBlip then RemoveBlip(currentBlip) end
    
    lib.notify({title = 'Čistič bazénů', description = 'Směna **zahájena!** Dojeď na vyznačené lokace.', type = 'info', duration = 7000})
    
    StartPoolLoop()
end)

RegisterNetEvent('md-jobmenu:poolcleaner:stop', function()
    if not onDuty then return end
    onDuty = false
    
    if currentBlip then RemoveBlip(currentBlip) end
    if currentZoneId then exports.ox_target:removeZone(currentZoneId) currentZoneId = nil end
    
    if DoesEntityExist(spawnedVehicle) then
        DeleteEntity(spawnedVehicle)
        spawnedVehicle = nil
    end

    lib.notify({title = 'Čistič bazénů', description = 'Směna **ukončena.**', type = 'info'})
end)

RegisterNetEvent('md-jobmenu:poolcleaner:vehicle', function()
    if DoesEntityExist(spawnedVehicle) then
        lib.notify({type = 'error', description = 'Vozidlo už máš **vytažené!**'})
    else
        ESX.Game.SpawnVehicle(JobConfig.vehicle, JobConfig.pedCoords, JobConfig.pedCoords.w, function(vehicle)
            spawnedVehicle = vehicle
            TaskWarpPedIntoVehicle(cache.ped, vehicle, -1)
            lib.notify({type = 'success', description = 'Vozidlo **přistaveno.**'})
        end)
    end
end)

function StartPoolLoop()
    remainingLocations = {table.unpack(JobConfig.locations)}
    NextPoolJob()
end

function NextPoolJob()
    if not onDuty then return end

    if currentZoneId then 
        exports.ox_target:removeZone(currentZoneId)
        currentZoneId = nil 
    end
    if currentBlip then RemoveBlip(currentBlip) end

    if #remainingLocations == 0 then
        lib.notify({title = 'Hotovo', description = 'Všechny bazény **vyčištěny!** Vrať se na depo.', type = 'success', duration = 7000})
        return
    end

    local randomIndex = math.random(1, #remainingLocations)
    local loc = remainingLocations[randomIndex]
    
    table.remove(remainingLocations, randomIndex)

    currentBlip = AddBlipForCoord(loc)
    SetBlipSprite(currentBlip, 1)
    SetBlipColour(currentBlip, 3)
    SetBlipRoute(currentBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Zakazka")
    EndTextCommandSetBlipName(currentBlip)

    currentZoneId = 'pool_zone_' .. math.random(100000, 999999)

    exports.ox_target:addSphereZone({
        name = currentZoneId,
        coords = loc,
        radius = 2.0,
        debug = Config.Debug,
        options = {
            {
                name = 'pool_work',
                icon = 'fa-solid fa-broom',
                label = 'Vyčistit',
                onSelect = function()
                    if lib.progressBar({
                        duration = 12000,
                        label = 'Čistíš...',
                        useWhileDead = false,
                        canCancel = false,
                        disable = {
                            car = true,
                            move = true,
                            combat = true
                        },
                    anim = {
                        dict = 'amb@world_human_janitor@male@idle_a',
                        clip = 'idle_a'
                    },
                    prop = {
                        model = 'prop_tool_broom',
                        bone = 28422,
                        pos = vec3(-0.005, 0.0, 0.0),
                        rot = vec3(360.0, 360.0, 0.0)
                    },
                    }) then
                        local reward = math.random(JobConfig.payoutMin, JobConfig.payoutMax)
                        TriggerServerEvent('md-jobmenu:addPayout', reward)
                        
                        if currentZoneId then
                            exports.ox_target:removeZone(currentZoneId)
                            currentZoneId = nil
                        end
                        if currentBlip then RemoveBlip(currentBlip) end

                        Wait(500)
                        NextPoolJob()
                    else
                        lib.notify({type = 'error', description = 'Práce přerušena.'})
                    end
                end
            }
        }
    })
end