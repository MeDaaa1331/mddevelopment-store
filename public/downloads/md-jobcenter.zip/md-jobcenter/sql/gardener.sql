CREATE TABLE IF NOT EXISTS `md_job_earnings` (
  `identifier` varchar(60) NOT NULL,
  `balance` int(11) NOT NULL DEFAULT 0,
  `total_earned` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`identifier`)
);