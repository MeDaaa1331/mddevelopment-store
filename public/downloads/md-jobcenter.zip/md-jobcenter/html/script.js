let currentJobKey = null;

window.addEventListener('message', function(event) {
    const data = event.data;

    if (data.action === 'open') {
        document.getElementById('app').style.display = 'flex';
        setTimeout(() => {
            document.getElementById('app').style.opacity = '1';
        }, 50);

        setupProfile(data.playerData);
        renderJobs(data.jobs);
    } 
    else if (data.action === 'close') {
        closeUI();
    }
});

function setupProfile(data) {
    document.getElementById('playerName').innerText = data.name;
    const formatMoney = (n) => n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    document.getElementById('totalEarned').innerText = formatMoney(data.total_earned) + ' $';
    document.getElementById('currentBalance').innerText = formatMoney(data.balance) + ' $';
}

function renderJobs(jobs) {
    const grid = document.getElementById('jobs-grid');
    grid.innerHTML = '';

    for (const [key, job] of Object.entries(jobs)) {
        const card = document.createElement('div');
        card.className = 'job-card';
        
        card.innerHTML = `
            <div class="job-icon-container">
                <i class="${job.icon}"></i>
            </div>
            
            <div class="card-header">
                <h3>${job.label}</h3>
            </div>

            <div class="card-details">
                <span><i class="fa-solid fa-sack-dollar"></i> ${job.payoutMin}-${job.payoutMax} $</span>
                <span><i class="fa-solid fa-location-dot"></i> ${job.locations ? job.locations.length : '?'} Lokací</span>
            </div>
            
            <div class="job-desc-short">
                ${job.description}
            </div>

            <button class="btn-view">Zobrazit Detaily</button>
        `;

        card.onclick = () => openJobModal(key, job);
        grid.appendChild(card);
    }
}

function openJobModal(key, job) {
    currentJobKey = key;
    
    document.getElementById('modal-job-name').innerText = job.label;
    document.getElementById('modal-job-desc').innerText = job.description;
    document.getElementById('modal-job-payout').innerText = `${job.payoutMin} $ - ${job.payoutMax} $`;

    const modal = document.getElementById('job-modal');
    modal.style.display = 'flex';
    setTimeout(() => { modal.classList.add('visible'); }, 10);
}

function closeModal() {
    const modal = document.getElementById('job-modal');
    modal.classList.remove('visible');
    setTimeout(() => { 
        modal.style.display = 'none'; 
        currentJobKey = null; 
    }, 200);
}

function triggerJob(action) {
    if (!currentJobKey) return;
    
    fetch(`https://${GetParentResourceName()}/triggerJobAction`, {
        method: 'POST',
        body: JSON.stringify({ job: currentJobKey, action: action })
    });
    
    if(action === 'start' || action === 'stop') {
        closeModal();
        closeUI();
    }
}

function withdrawMoney() {
    fetch(`https://${GetParentResourceName()}/withdraw`, { method: 'POST' });
    document.getElementById('currentBalance').innerText = '0 $';
}

function closeUI() {
    const app = document.getElementById('app');
    app.style.opacity = '0';
    setTimeout(() => {
        app.style.display = 'none';
        closeModal();
    }, 200);
    fetch(`https://${GetParentResourceName()}/close`, { method: 'POST' });
}

document.onkeyup = function (data) {
    if (data.which == 27) {
        closeUI();
    }
};