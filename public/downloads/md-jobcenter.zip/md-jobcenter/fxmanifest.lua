server_script '@ElectronAC/src/include/server.lua'
client_script '@ElectronAC/src/include/client.lua'

fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'MeDaaa'
description 'Modular job menu including lots of pre-made jobs | https://discord.gg/Ze4m2Uyxjw'
version '1.0'

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'config.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/*',
    'jobs/*_server.lua'
}

client_scripts {
    'client/*',
    'jobs/*_client.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/img/*'
}

dependencies {
    'es_extended',
    'ox_lib',
    'ox_target',
    'oxmysql'
}

escrow_ignore { 
    'config.lua',
} 