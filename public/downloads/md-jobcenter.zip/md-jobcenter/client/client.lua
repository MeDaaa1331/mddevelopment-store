local ESX = exports['es_extended']:getSharedObject()

CreateThread(function()
    local cfg = Config.MainPed
    local hash = GetHashKey(cfg.model)
    
    RequestModel(hash)
    while not HasModelLoaded(hash) do Wait(10) end

    local ped = CreatePed(4, hash, cfg.coords.x, cfg.coords.y, cfg.coords.z, cfg.coords.w, false, true)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)

    exports.ox_target:addLocalEntity(ped, {
        {
            name = 'open_jobmenu',
            icon = 'fa-solid fa-briefcase',
            label = cfg.label,
            onSelect = function()
                OpenJobMenu()
            end
        }
    })
end)

function OpenJobMenu()
    ESX.TriggerServerCallback('md-jobmenu:getData', function(data)
        SetNuiFocus(true, true)
        SendNUIMessage({
            action = 'open',
            playerData = data,
            jobs = Config.Jobs
        })
    end)
end

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('withdraw', function(_, cb)
    TriggerServerEvent('md-jobmenu:withdraw')
    cb('ok')
end)

RegisterNUICallback('triggerJobAction', function(data, cb)
    local eventName = 'md-jobmenu:' .. data.job .. ':' .. data.action
    TriggerEvent(eventName)
    cb('ok')
end)

CreateThread(function()
    local blip = AddBlipForCoord(Config.MainPed.coords)
    
    SetBlipSprite(blip, Config.Blip.Sprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, Config.Blip.Scale)
    SetBlipColour(blip, Config.Blip.Color)
    
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(Config.Blip.Label)
    EndTextCommandSetBlipName(blip)
end)