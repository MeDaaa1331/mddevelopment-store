local ESX = exports['es_extended']:getSharedObject()

ESX.RegisterServerCallback('md-jobmenu:getData', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return end

    MySQL.query('SELECT balance, total_earned FROM md_job_earnings WHERE identifier = ?', {xPlayer.identifier}, function(result)
        local data = {
            name = xPlayer.getName(),
            balance = 0,
            total_earned = 0
        }
        
        if result[1] then
            data.balance = result[1].balance
            data.total_earned = result[1].total_earned
        else
            MySQL.insert('INSERT INTO md_job_earnings (identifier) VALUES (?)', {xPlayer.identifier})
        end
        
        cb(data)
    end)
end)

RegisterNetEvent('md-jobmenu:withdraw', function()
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)

    MySQL.query('SELECT balance FROM md_job_earnings WHERE identifier = ?', {xPlayer.identifier}, function(result)
        if result[1] and result[1].balance > 0 then
            local amount = result[1].balance
            
            xPlayer.addMoney(amount)
            MySQL.update('UPDATE md_job_earnings SET balance = 0 WHERE identifier = ?', {xPlayer.identifier})
            
            TriggerClientEvent('ox_lib:notify', src, {type = 'success', description = 'Vybral jsi ' .. amount .. '$'})
        else
            TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = 'Nemáš **nic** k výběru!'})
        end
    end)
end)

RegisterNetEvent('md-jobmenu:addPayout', function(amount)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    
    MySQL.update('UPDATE md_job_earnings SET balance = balance + ?, total_earned = total_earned + ? WHERE identifier = ?', {
        amount, amount, xPlayer.identifier
    })
    
    TriggerClientEvent('ox_lib:notify', src, {type = 'success', description = 'Výdělek ' .. amount .. '$ **připsán na výplatní pásku.**'})
    TriggerClientEvent('ox_lib:notify', src, {type = 'info', description = 'Pokračuj na **další zakázku!**', duration = 7000})
end)