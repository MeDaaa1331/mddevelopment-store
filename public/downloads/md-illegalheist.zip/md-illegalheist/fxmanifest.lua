fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'MeDaaa'
description 'Illegal warehouse heist. Custom illegal tablet, bodyguards, crates and more... | discord.gg/Ze4m2Uyxjw'
version '1.0'

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client/main.lua',
    'client/peds.lua'
}

server_scripts {
    'server/main.lua'
}

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/script.js',
    'web/img/*.png',
    'locales/*.json'
}

dependencies {
    'es_extended',
    'ox_lib',
    'ox_inventory',
    'ox_target'
}

escrow_ignore {
    'config.lua',
}