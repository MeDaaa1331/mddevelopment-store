let timerInterval = null;

window.addEventListener('message', function(event) {
    if (event.data.action === 'open') {
        openTablet(event.data.data);
    }
});

document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeTablet();
    }
});

function closeTablet() {
    document.getElementById('tablet-container').style.display = 'none';
    
    if (timerInterval) {
        clearInterval(timerInterval);
        timerInterval = null;
    }

    fetch(`https://${GetParentResourceName()}/close`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({})
    });
}

function openTablet(data) {
    document.getElementById('tablet-container').style.display = 'flex';
    document.getElementById('player-name').innerText = data.playerName;

    const cooldownBadge = document.getElementById('global-timer');
    const cooldownText = document.getElementById('cooldown-time');
    const heistList = document.getElementById('heist-list');
    
    heistList.innerHTML = '';
    
    let remainingSeconds = 0;
    if (data.cooldownEnd > 0) {
        remainingSeconds = data.cooldownEnd - data.serverTime;
    }

    const isHeistActive = data.isHeistActive;
    const isGlobalCooldown = remainingSeconds > 0;

    const updateTimerDisplay = () => {
        if (remainingSeconds > 0) {
            remainingSeconds--;
            
            const minutes = Math.floor(remainingSeconds / 60);
            const seconds = remainingSeconds % 60;
            const formattedTime = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
            
            cooldownText.innerText = formattedTime;
        } else {
            cooldownBadge.classList.add('hidden');
            clearInterval(timerInterval);
        }
    };

    if (isGlobalCooldown || isHeistActive) {
        cooldownBadge.classList.remove('hidden');
        
        if (isGlobalCooldown) {
            updateTimerDisplay();
            if (timerInterval) clearInterval(timerInterval);
            timerInterval = setInterval(updateTimerDisplay, 1000);
        } else {
            cooldownText.innerText = "ACTIVE";
        }
    } else {
        cooldownBadge.classList.add('hidden');
    }

    for (const [id, heist] of Object.entries(data.heists)) {
        const card = document.createElement('div');
        card.className = 'heist-card';

        let btnDisabled = (isGlobalCooldown || isHeistActive) ? 'disabled' : '';
        
        let btnText = data.locales.start; 
        if (isGlobalCooldown) btnText = data.locales.locked;
        if (isHeistActive) btnText = data.locales.progress;

        card.innerHTML = `
            <img src="${heist.image}" alt="${heist.label}" class="heist-img">
            <div class="heist-info">
                <h3>${heist.label}</h3>
                <span class="difficulty">${heist.difficulty}</span>
                <p class="desc">${heist.description}</p>
                <div class="stats">
                    <div class="stat-item"><span>ODHAD ZISKU</span>${heist.payout}</div>
                    <div class="stat-item"><span>TÝM</span>1-4</div>
                </div>
                <button class="btn-start" onclick="startHeist('${id}')" ${btnDisabled}>${btnText}</button>
            </div>
        `;
        heistList.appendChild(card);
    }
}

function startHeist(heistId) {
    fetch(`https://${GetParentResourceName()}/startHeist`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({
            heistId: heistId
        })
    }).then(resp => resp.json()).then(resp => {
        if (resp === true) {
            closeTablet();
        } else {
            console.log("Heist start failed");
        }
    });
}