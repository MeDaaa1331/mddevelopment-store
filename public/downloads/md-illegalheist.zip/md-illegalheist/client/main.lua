lib.locale()
local isUiOpen = false
local currentHeist = nil
local spawnedCrates = {}

RegisterNetEvent('md_illegalheist:openTablet', function()
    local data = lib.callback.await('md_illegalheist:getData', false)
    
    data.locales = {
        start = locale('ui_start_heist') or 'START HEIST',
        locked = locale('ui_heist_locked') or 'LOCKED',
        progress = locale('ui_heist_progress') or 'IN PROGRESS'
    }
    
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        data = data
    })
    isUiOpen = true
end)

RegisterNUICallback('close', function(_, cb)
    SetNuiFocus(false, false)
    isUiOpen = false
    cb('ok')
end)

RegisterNUICallback('startHeist', function(data, cb)
    local success = lib.callback.await('md_illegalheist:startHeist', false, data.heistId)
    
    if success then
        currentHeist = data.heistId
        SetNewWaypoint(Config.Heists[currentHeist].entryDoor.x, Config.Heists[currentHeist].entryDoor.y)
        lib.notify({ title = locale('tablet_title'), description = locale('location_marked'), type = 'success' })
        InitHeistLogic(currentHeist)
        cb(true)
    else
        cb(false)
    end
end)

function InitHeistLogic(heistId)
    local heistData = Config.Heists[heistId]
    
    exports.ox_target:addSphereZone({
        coords = heistData.entryDoor,
        radius = 1.5,
        debug = Config.Debug,
        options = {
            {
                name = 'heist_enter',
                icon = 'fa-solid fa-lock',
                label = locale('enter_warehouse'),
                onSelect = function()
                    AttemptBreach(heistId)
                end
            }
        }
    })
end

function AttemptBreach(heistId)
    local count = exports.ox_inventory:Search('count', Config.LockpickItem)
    if count > 0 then
        local success = exports['lockpick']:startLockpick(3)
        
        TriggerServerEvent('md_illegalheist:removeLockpick')

        if success then
            EnterWarehouse(heistId)
        else
            lib.notify({ type = 'error', description = locale('lockpick_failed') })
        end
    else
        lib.notify({ type = 'error', description = locale('missing_lockpick') })
    end
end

function EnterWarehouse(heistId)
    local heistData = Config.Heists[heistId]
    DoScreenFadeOut(500)
    Wait(500)
    SetEntityCoords(cache.ped, heistData.interiorSpawn)
    SetEntityHeading(cache.ped, 0.0)
    Wait(500)
    DoScreenFadeIn(500)
    
    SpawnInsideProps(heistId)
    TriggerEvent('md_illegalheist:spawnGuards', heistId)
    
    exports.ox_target:addSphereZone({
        coords = heistData.exitDoor,
        radius = 1.5,
        options = {
            {
                icon = 'fa-solid fa-door-open',
                label = locale('exit_warehouse'),
                onSelect = function()
                    SetEntityCoords(cache.ped, heistData.entryDoor)
                end
            }
        }
    })
end

function SpawnInsideProps(heistId)
    local heistData = Config.Heists[heistId]
    
    for i, crateData in ipairs(heistData.crates) do
        local obj = CreateObject(joaat('prop_box_wood02a_pu'), crateData.coords, false, false, false)
        SetEntityHeading(obj, crateData.heading)
        FreezeEntityPosition(obj, true)
        table.insert(spawnedCrates, obj)
        
        exports.ox_target:addLocalEntity(obj, {
            {
                name = 'heist_crate_'..i,
                icon = 'fa-solid fa-crowbar',
                label = locale('loot_crate'),
                onSelect = function()
                    local searchResult = exports.ox_inventory:Search('count', Config.WrenchItem)
                    local count = 0

                    if type(searchResult) == 'number' then
                        count = searchResult
                    elseif type(searchResult) == 'table' then
                        for _, amount in pairs(searchResult) do
                            count = count + amount
                        end
                    end

                    if count > 0 then
                        LootCrate(heistId, i, obj)
                    else
                        lib.notify({ type = 'error', description = locale('need_wrench') or 'Potřebuješ hasák!' })
                    end
                end
            }
        })
    end
end

function LootCrate(heistId, index, entity)
    local success = lib.skillCheck({'easy', 'medium', 'medium', 'medium', 'easy', 'medium'}, {'w', 'a', 's', 'd'})
    
    if success then
        if lib.progressBar({
            duration = 60000,
            label = locale('looting'),
            useWhileDead = false,
            canCancel = false,
            disable = { move = true, car = true, combat = true },
            anim = { dict = 'mini@repair', clip = 'fixing_a_ped' }
        }) then
            TriggerServerEvent('md_illegalheist:rewardCrate', heistId, index)
            exports.ox_target:removeLocalEntity(entity)
            DeleteEntity(entity)
        end
    else
        lib.notify({ type = 'error', description = locale('skillcheck_failed') })
    end
end

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        for _, obj in pairs(spawnedCrates) do
            if DoesEntityExist(obj) then DeleteEntity(obj) end
        end
    end
end)

RegisterNetEvent('md_illegalheist:notifyDispatch', function(coords)
    if GetResourceState('cd_dispatch') == 'started' then
        TriggerEvent('cd_dispatch:GetPlayerPos')
        TriggerServerEvent('cd_dispatch:AddNotification', {
            job_table = {'police', 'sheriff'}, 
            coords = coords,
            title = Config.DispatchTitle,
            message = Config.DispatchMessage, 
            flash = 0,
            unique_id = tostring(math.random(0000000,9999999)),
            sound = 1,
            blip = {
                sprite = 161, 
                scale = 1.2, 
                colour = 3,
                flashes = false, 
                text = Config.DispatchTitle,
                time = 5,
                radius = 0,
            }
        })
    end
end)