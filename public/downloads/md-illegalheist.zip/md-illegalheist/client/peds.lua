local spawnedGuards = {}

RegisterNetEvent('md_illegalheist:spawnGuards', function(heistId)
    local heistData = Config.Heists[heistId]
    if not heistData.guards then return end
    
    for _, ped in pairs(spawnedGuards) do
        if DoesEntityExist(ped) then DeleteEntity(ped) end
    end
    spawnedGuards = {}

    lib.requestModel('g_m_y_ballaeast_01')
    lib.requestModel('s_m_y_blackops_01')

    local guardGroup = joaat('HEIST_GUARDS')
    AddRelationshipGroup('HEIST_GUARDS')

    SetRelationshipBetweenGroups(0, guardGroup, guardGroup)

    SetRelationshipBetweenGroups(5, guardGroup, joaat('PLAYER'))
    SetRelationshipBetweenGroups(5, joaat('PLAYER'), guardGroup)

    for i, guardData in ipairs(heistData.guards) do
        local ped = CreatePed(4, joaat(guardData.model), guardData.coords.x, guardData.coords.y, guardData.coords.z, guardData.coords.w, true, true)
        
        local timer = 0
        while not NetworkGetEntityIsNetworked(ped) and timer < 10 do
            Wait(100)
            timer = timer + 1
        end

        SetPedRelationshipGroupHash(ped, guardGroup)

        SetPedArmour(ped, 100)
        SetPedAccuracy(ped, 70)
        SetPedFleeAttributes(ped, 0, 0)
        SetPedCombatAttributes(ped, 46, true)
        SetPedDropsWeaponsWhenDead(ped, false)
        GiveWeaponToPed(ped, joaat(guardData.weapon), 250, false, true)

        TaskCombatPed(ped, cache.ped, 0, 16)

        table.insert(spawnedGuards, ped)
        
        exports.ox_target:addLocalEntity(ped, {
            {
                name = 'loot_guard_'..i,
                icon = 'fa-solid fa-gun',
                label = locale('loot_guard'),
                canInteract = function(entity)
                    return IsPedDeadOrDying(entity, true) 
                           and not Entity(entity).state.looted 
                           and not Entity(entity).state.lootingBusy
                end,
                onSelect = function(data)
                    local entity = data.entity
                    local netId = NetworkGetNetworkIdFromEntity(entity)

                    local canLoot = lib.callback.await('md_illegalheist:canLootGuard', false, netId)

                    if canLoot then
                        if lib.progressBar({
                            duration = 5000,
                            label = locale('guard_looting_progress') or 'Okrádání...',
                            useWhileDead = false,
                            canCancel = true,
                            disable = { move = true, car = true, combat = true },
                            anim = { dict = 'random@domestic', clip = 'pickup_low' }
                        }) then
                            TriggerServerEvent('md_illegalheist:lootGuard', netId)
                        else
                            TriggerServerEvent('md_illegalheist:cancelLootGuard', netId)
                        end
                    else
                        lib.notify({ type = 'error', description = 'Tuto osobu již někdo okrádá nebo je prázdná.' })
                    end
                end
            }
        })
    end
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then
        for _, ped in pairs(spawnedGuards) do
            if DoesEntityExist(ped) then DeleteEntity(ped) end
        end
    end
end)