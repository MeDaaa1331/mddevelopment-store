Config = {}

Config.Debug = false

Config.GlobalCooldown = 30

Config.DispatchTitle = "Vloupaní do skladu"
Config.DispatchCode = "10-90"
Config.DispatchMessage = "Je hlášeno vloupaní do soukromého skladu, ozbrojení pachatelé."

Config.TabletItem = 'md-illegalmenu'
Config.LockpickItem = 'lockpick'
Config.WrenchItem = 'weapon_wrench'

Config.Heists = {
    ['warehouse_a'] = {
        label = "Malý Sklad",
        description = "Menší sklad, méně stráží, ale menší zisk. Ideální pro začátečníky.",
        image = "./img/loc1.png",
        difficulty = "Snadný",
        payout = "~$8,000",
        
        entryDoor = vec3(1395.5341, 3623.6936, 35.0122),
        entryHeading = 90.0,
        
        interiorSpawn = vec3(1048.7913, -3097.1355, -39.0061),
        exitDoor = vec3(1048.0264, -3097.0405, -39.0000),
        
        guards = {
            { model = 'g_m_y_ballaeast_01', coords = vec4(1069.7740, -3107.5469, -38.9999, 84.4341), weapon = 'WEAPON_PISTOL' },
            { model = 'g_m_y_ballaeast_01', coords = vec4(1070.1837, -3095.4990, -38.9999, 119.6789), weapon = 'WEAPON_COMBATPISTOL' },
            { model = 'g_m_y_ballaeast_01', coords = vec4(1062.4886, -3102.8967, -38.9999, 75.8224), weapon = 'WEAPON_HEAVYPISTOL' },
            { model = 'g_m_y_ballaeast_01', coords = vec4(1050.0277, -3109.8081, -39.0000, 351.7055), weapon = 'WEAPON_PISTOL50' },
        },
        
        crates = {
            { coords = vec3(1057.9764, -3109.7917, -39.9999), heading = 1.9362 },
            { coords = vec3(1057.9503, -3095.3186, -39.9999), heading = 179.1424 },
        },
        
        lootTable = {
            { item = 'money', min = 2000, max = 5000, chance = 100 },
            { item = 'zvireci_kuze', min = 1, max = 3, chance = 60 },
            { item = 'phone', min = 1, max = 2, chance = 60 },
            { item = 'weapon_pistol', min = 1, max = 1, chance = 30, metadata = { durability = 20 } },
            { item = 'weapon_combatpistol', min = 1, max = 1, chance = 20, metadata = { durability = 20 } },
            { item = 'at_suppressor_heavy', min = 1, max = 1, chance = 5 },
        }
    },
    
    ['warehouse_b'] = {
        label = "Velký bunkr",
        description = "Velký bunkr s těžkým ozbrojením. Rozsáhlé místnosti, vysoké riziko, množství beden a vysoký zisk.",
        image = "./img/loc2.png",
        difficulty = "Těžký",
        payout = "~$30,000",
        
        entryDoor = vec3(306.8636, -2787.7793, 6.1052),
        entryHeading = 180.0,
        
        interiorSpawn = vec3(896.4188, -3245.7815, -98.2429),
        exitDoor = vec3(896.4188, -3245.7815, -98.2429),
        
        guards = {
            { model = 's_m_y_blackops_01', coords = vec4(886.3021, -3236.9031, -98.2875, 226.5537), weapon = 'WEAPON_HEAVYPISTOL' },
            { model = 's_m_y_blackops_01', coords = vec4(880.7560, -3248.9399, -98.2911, 287.6243), weapon = 'WEAPON_PISTOL50' },
            { model = 's_m_y_blackops_01', coords = vec4(904.6971, -3237.8323, -98.2944, 94.9337), weapon = 'WEAPON_CARBINERIFLE_MK2' },
            { model = 's_m_y_blackops_01', coords = vec4(843.3853, -3234.0835, -98.6992, 238.4099), weapon = 'WEAPON_PISTOL_MK2' },
            { model = 's_m_y_blackops_01', coords = vec4(828.1697, -3240.6477, -98.7597, 255.3125), weapon = 'WEAPON_COMBATPISTOL' },
            { model = 's_m_y_blackops_01', coords = vec4(855.8210, -3213.8657, -98.5032, 183.2055), weapon = 'WEAPON_MICROSMG' },
            { model = 's_m_y_blackops_01', coords = vec4(879.6246, -3185.1543, -96.7242, 107.3406), weapon = 'WEAPON_MICROSMG' },
            { model = 's_m_y_blackops_01', coords = vec4(893.8306, -3207.0569, -98.1963, 234.0914), weapon = 'WEAPON_CARBINERIFLE' },
            { model = 's_m_y_blackops_01', coords = vec4(905.0974, -3230.1414, -98.2944, 23.1004), weapon = 'WEAPON_MICROSMG' },
            { model = 's_m_y_blackops_01', coords = vec4(921.3780, -3215.2681, -98.2641, 159.5983), weapon = 'WEAPON_MICROSMG' },
            { model = 's_m_y_blackops_01', coords = vec4(948.9646, -3201.7168, -98.2693, 123.0084), weapon = 'WEAPON_ASSAULTRIFLE' },
            { model = 's_m_y_blackops_01', coords = vec4(950.3566, -3225.8423, -98.2939, 36.7426), weapon = 'WEAPON_MICROSMG' },
            { model = 's_m_y_blackops_01', coords = vec4(942.5211, -3239.3625, -98.2689, 83.2159), weapon = 'WEAPON_MICROSMG' },
            { model = 's_m_y_blackops_01', coords = vec4(876.5700, -3204.9790, -97.2619, 85.8493), weapon = 'WEAPON_CARBINERIFLE' },
            { model = 's_m_y_blackops_01', coords = vec4(894.5386, -3177.8347, -97.1237, 166.8781), weapon = 'WEAPON_MICROSMG' },
            { model = 's_m_y_blackops_01', coords = vec4(901.1552, -3205.9807, -97.1892, 120.0491), weapon = 'WEAPON_ASSAULTRIFLE' },
        },
        
        crates = {
            { coords = vec3(826.4106, -3233.3882, -100.0583), heading = 255.5075 },
            { coords = vec3(868.3917, -3190.0906, -98.2397), heading = 11.4272 },
            { coords = vec3(891.6583, -3226.3579, -99.2334), heading = 296.7230 },
            { coords = vec3(949.3556, -3219.2937, -99.2890), heading = 93.9641 },
        },
        
        lootTable = {
            { item = 'money', min = 5000, max = 10000, chance = 100 },
            { item = 'bracelet', min = 1, max = 2, chance = 60 },
            { item = 'watch', min = 1, max = 2, chance = 60 },
            { item = 'monitor', min = 1, max = 1, chance = 60 },
            { item = 'mdshovel', min = 1, max = 1, chance = 60 },
            { item = 'ring', min = 1, max = 1, chance = 60 },
            { item = 'meth', min = 2, max = 5, chance = 60 },
            { item = 'weapon_pistol', min = 1, max = 1, chance = 30, metadata = { durability = 30 } },
            { item = 'weapon_microsmg', min = 1, max = 1, chance = 10, metadata = { durability = 25 } },
            { item = 'weapon_combatpistol', min = 1, max = 1, chance = 20, metadata = { durability = 30 } },
            { item = 'weapon_heavypistol', min = 1, max = 1, chance = 15, metadata = { durability = 20 } },
            { item = 'at_suppressor_heavy', min = 1, max = 1, chance = 10 },
            { item = 'at_clip_extended_rifle', min = 1, max = 1, chance = 10 },
        }
    }
}