lib.locale()

local GlobalCooldown = 0
local ActiveHeist = nil
local LootedCrates = {}

lib.callback.register('md_illegalheist:getData', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    local cooldownEnd = 0
    if GlobalCooldown > os.time() then
        cooldownEnd = GlobalCooldown
    end

    return {
        playerName = xPlayer.getName(),
        isHeistActive = ActiveHeist ~= nil,
        cooldownEnd = cooldownEnd,
        serverTime = os.time(),
        heists = Config.Heists
    }
end)

lib.callback.register('md_illegalheist:startHeist', function(source, heistId)
    if GlobalCooldown > os.time() then return false end
    if ActiveHeist then return false end
    
    ActiveHeist = heistId
    LootedCrates = {}
    
    TriggerClientEvent('md_illegalheist:notifyDispatch', -1, Config.Heists[heistId].entryDoor)
    
    return true
end)

ESX.RegisterUsableItem(Config.TabletItem, function(source)
    TriggerClientEvent('md_illegalheist:openTablet', source)
end)

RegisterNetEvent('md_illegalheist:finishHeist', function()
    local src = source
    if ActiveHeist then
        ActiveHeist = nil
        GlobalCooldown = os.time() + (Config.GlobalCooldown * 60)
        TriggerClientEvent('md_illegalheist:syncHeistState', -1, false)
    end
end)

RegisterNetEvent('md_illegalheist:rewardCrate', function(heistId, crateIndex)
    local src = source
    
    if LootedCrates[crateIndex] then return end
    LootedCrates[crateIndex] = true

    local lootTable = Config.Heists[heistId].lootTable
    if not lootTable then return end

    for _, reward in ipairs(lootTable) do
        if math.random(1, 100) <= reward.chance then
            local count = math.random(reward.min, reward.max)
            local metadata = reward.metadata or {}
            
            if exports.ox_inventory:CanCarryItem(src, reward.item, count) then
                exports.ox_inventory:AddItem(src, reward.item, count, metadata)
                TriggerClientEvent('ox_lib:notify', src, { type = 'success', description = string.format(locale('received_loot'), count, reward.item) })
            end
        end
    end
end)

lib.callback.register('md_illegalheist:canLootGuard', function(source, netId)
    local entity = NetworkGetEntityFromNetworkId(netId)
    if not DoesEntityExist(entity) then return false end
    
    if Entity(entity).state.looted or Entity(entity).state.lootingBusy then
        return false
    end

    Entity(entity).state:set('lootingBusy', true, true)
    return true
end)

RegisterNetEvent('md_illegalheist:cancelLootGuard', function(netId)
    local entity = NetworkGetEntityFromNetworkId(netId)
    if DoesEntityExist(entity) then
        Entity(entity).state:set('lootingBusy', false, true)
    end
end)

RegisterNetEvent('md_illegalheist:lootGuard', function(netId)
    local src = source
    local entity = NetworkGetEntityFromNetworkId(netId)
    
    if not DoesEntityExist(entity) then return end

    Entity(entity).state:set('looted', true, true)
    Entity(entity).state:set('lootingBusy', false, true)

    local weaponName = 'WEAPON_PISTOL' 
    exports.ox_inventory:AddItem(src, weaponName, 1, { durability = math.random(10, 30), ammo = 0 })
end)

RegisterNetEvent('md_illegalheist:removeLockpick', function()
    local src = source
    exports.ox_inventory:RemoveItem(src, Config.LockpickItem, 1)
end)