local robbing = false
local ox_inventory = exports.ox_inventory

local function getUsableShovel()
    local items = ox_inventory:Search("slots", Config.ShovelItemName)

    if #items == 0 then
        return false
    end

    for _, item in pairs(items) do
        item.metadata = item.metadata or {}
        item.metadata.durability = item.metadata.durability or 100

        local newDurability = item.metadata.durability - Config.DurabilityReduce
        if newDurability >= 0 then
            return item, newDurability
        end
    end

    return false
end

local function VykradniHrob(graveId)
    if robbing then return end

    local canRob, remainingMinutes = lib.callback.await("cayo_grave_robbing:checkCooldown", false, graveId)
    if not canRob then
        return lib.notify({
            title = "Chyba",
            description = ("Tento hrob **byl nedávno vykraden.** Zkus to znovu za **%d minut.**"):format(remainingMinutes),
            type = "error",
            duration = 7000
        })
    end

    local usableShovel = getUsableShovel()
    if not usableShovel then
        return lib.notify({
            title = "Chyba",
            description = "Nemáš u sebe lopatu.",
            type = "error",
            duration = 5000
        })
    end

    local started = lib.callback.await("cayo_grave_robbing:startRobbery", false, graveId)
    if not started then
        return lib.notify({
            title = "Chyba",
            description = "Někdo **již vykrádá** tento hrob!",
            type = "error",
            duration = 5000
        })
    end

    robbing = true
    
    ExecuteCommand("e dig")
    
    exports["memorygame"]:thermiteminigame(7, 2, 3, 15,
        function()
            local success = lib.progressBar({
                duration = Config.DobaAnimace,
                label = "Kopeš hrob...",
                useWhileDead = false,
                canCancel = true,
                disable = {
                    move = true,
                    car = true,
                    combat = true,
                },
            })

            ClearPedTasks(cache.ped)
            ExecuteCommand("e c")

            if not success then
                robbing = false
                TriggerServerEvent("cayo_grave_robbing:resetRobberyStatus", graveId)
                return lib.notify({
                    title = "Chyba",
                    description = "**Přerušil** jsi vykrádání hrobu!",
                    type = "error"
                })
            end

            local result, message = lib.callback.await("cayo_grave_robbing:finished", false, graveId)
            robbing = false
            if result then
                lib.notify({
                    title = "Úspěch",
                    description = message,
                    type = "success",
                    duration = 7000
                })
            elseif message then
                lib.notify({
                    title = "Neúspěch",
                    description = message,
                    type = "error",
                    duration = 7000
                })
            end
        end,
        function()
            ClearPedTasks(cache.ped)
            lib.callback.await("cayo_grave_robbing:failed", false, graveId)
            robbing = false
            TriggerServerEvent("cayo_grave_robbing:resetRobberyStatus", graveId)
            lib.notify({
                title = "Neúspěch",
                description = "**Nepodařilo** se ti vykopat hrob!",
                type = "error"
            })
        end
    )
end

for i, hrob in ipairs(Config.Hroby) do
    exports.ox_target:addBoxZone({
        coords = hrob.coords,
        size = vec3(hrob.length, hrob.width, 1.0),
        rotation = hrob.heading,
        debug = false,
        options = {
            {
                name = "vykradni_hrob_"..i,
                label = "Vykopat hrob",
                icon = "fa-solid fa-user-secret",
                distance = 1.5,
                onSelect = function()
                    VykradniHrob(i)
                end,
            }
        }
    })
end