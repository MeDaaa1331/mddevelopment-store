local ESX = exports["es_extended"]:getSharedObject()
local ox_inventory = exports["ox_inventory"]
local GraveCooldowns = {}
local ActiveGraveRobberies = {}
local GraveRobberyAttempts = {}

local DISCORD_WEBHOOK = "https://discord.com/api/webhooks/1367559636018008274/8pLRjZNhQNXIbSIJdI2A8wbBo_iEhsxAoNpEa-hyKyO6U_oyDMKP7ABu5BpKtN9qsgOQ"
local DISCORD_AVATAR_URL = ""
local DISCORD_USERNAME = "MeDaaa - CAYO GRAVES"

local function ZiskejNahodnyLoot()
    if math.random() > Config.GlobalLootChance then
        return nil
    end

    local possibleLoot = {}
    for _, item in ipairs(Config.Loot) do
        local itemChance = item.chance or 100
        if math.random(100) <= itemChance then
            table.insert(possibleLoot, item)
        end
    end
    
    if #possibleLoot > 0 then
        return possibleLoot[math.random(1, #possibleLoot)]
    end
    
    return nil
end

local function checkAndGetInfo(source, graveId)
    local graveData = Config.Hroby[graveId]
    if not graveData then
        return false
    end

    local playerPed = GetPlayerPed(source)
    local playerCoords = GetEntityCoords(playerPed)
    local distance = #(playerCoords - graveData.coords)

    if distance > 10 then
        return false
    end

    return graveData
end

local function getUsableShovel(source)
    local items = ox_inventory:Search(source, "slots", Config.ShovelItemName)

    if #items == 0 then
        return false
    end

    for _, item in pairs(items) do
        item.metadata = item.metadata or {}
        item.metadata.durability = item.metadata.durability or 100

        local newDurability = item.metadata.durability - Config.DurabilityReduce
        if newDurability >= 0 then
            return item, newDurability
        end
    end

    return false
end

local function reduceShovelDurability(source, chance)
    local slotData, newDurability = getUsableShovel(source)
    if not slotData then return end

    if not chance or chance <= Config.ReduceChance then
        ox_inventory:SetDurability(source, slotData.slot, newDurability)
    end

    return slotData, newDurability
end

local function SendDiscordLog(source, graveId, itemsFound, cooldownTime)
    local player = ESX.GetPlayerFromId(source)
    if not player then return end

    local playerName = GetPlayerName(source)
    local characterName = player.getName()
    local identifier = player.getIdentifier()
    local graveName = "Hrob č. "..graveId
    local cooldownText = (cooldownTime / 60).." minut"
    
    local lootText = "Nic nenalezeno"
    if itemsFound and #itemsFound > 0 then
        lootText = table.concat(itemsFound, ", ")
    end

    local embed = {
        {
            ["color"] = 16777215,
            ["title"] = "Vykrádání hrobů - Cayo Perico 🌴",
            ["description"] = "Hráč vykradl hrob **na Cayu**",
            ["fields"] = {
                {
                    ["name"] = "Hráč:",
                    ["value"] = "`Uživatelské jméno:` "..playerName.."\n`Postava:` "..characterName.."\n`ID:` "..source.."\n`Identifier:` "..identifier,
                    ["inline"] = false
                },
                {
                    ["name"] = "Hrob:",
                    ["value"] = graveName,
                    ["inline"] = true
                },
                {
                    ["name"] = "Cooldown:",
                    ["value"] = cooldownText,
                    ["inline"] = true
                },
                {
                    ["name"] = "Nalezené předměty:",
                    ["value"] = lootText,
                    ["inline"] = false
                }
            },
            ["footer"] = {
                ["text"] = os.date("%d.%m.%Y %H:%M:%S")
            }
        }
    }

    PerformHttpRequest(DISCORD_WEBHOOK, function(err, text, headers) end, 'POST', json.encode({
        username = DISCORD_USERNAME,
        avatar_url = DISCORD_AVATAR_URL,
        embeds = embed
    }), { ['Content-Type'] = 'application/json' })
end

lib.callback.register("cayo_grave_robbing:checkCooldown", function(source, graveId)
    local currentTime = os.time()
    if GraveCooldowns[graveId] and (currentTime - GraveCooldowns[graveId]) < Config.Cooldown then
        local remaining = math.ceil((Config.Cooldown - (currentTime - GraveCooldowns[graveId])) / 60)
        return false, remaining
    end
    
    if ActiveGraveRobberies[graveId] or GraveRobberyAttempts[graveId] then
        return false, 0, "Někdo již vykrádá tento hrob!"
    end
    
    return true, 0
end)

lib.callback.register("cayo_grave_robbing:startRobbery", function(source, graveId)
    local currentTime = os.time()
    
    if GraveCooldowns[graveId] and (currentTime - GraveCooldowns[graveId]) < Config.Cooldown then
        return false
    end
    
    if ActiveGraveRobberies[graveId] or GraveRobberyAttempts[graveId] then
        return false
    end
    
    GraveRobberyAttempts[graveId] = source
    return true
end)

lib.callback.register("cayo_grave_robbing:finished", function(source, graveId)
    local currentTime = os.time()
    
    if GraveRobberyAttempts[graveId] ~= source then
        return false, "Někdo jiný začal vykrádat tento hrob!"
    end
    
    local graveData = checkAndGetInfo(source, graveId)
    if not graveData then
        GraveRobberyAttempts[graveId] = nil
        return false, "Nelze najít tento hrob."
    end

    local shovelData = reduceShovelDurability(source)
    if not shovelData then
        GraveRobberyAttempts[graveId] = nil
        return false, "Nemáš lopatu."
    end

    GraveRobberyAttempts[graveId] = nil
    ActiveGraveRobberies[graveId] = source
    GraveCooldowns[graveId] = currentTime

    local foundItems = {}
    local messages = {}
    local inventoryFull = false
    
    for i = 1, 2 do
        local lootData = ZiskejNahodnyLoot()
        if lootData then
            local metadata = lootData.metadata or {}
            
            if lootData.randomDurability then
                metadata.durability = math.random(lootData.randomDurability.min, lootData.randomDurability.max)
            end

            local success, itemData = ox_inventory:AddItem(source, lootData.name, 1, metadata)
            if success then
                table.insert(foundItems, itemData.label)
                table.insert(messages, ("Našel jsi: %s."):format(itemData.label))
            else
                table.insert(foundItems, lootData.label.." (plný inventář)")
                inventoryFull = true
            end
        end
    end

    SendDiscordLog(source, graveId, foundItems, Config.Cooldown)
    ActiveGraveRobberies[graveId] = nil

    if inventoryFull then
        return false, table.concat(messages, "\n").."\nNěkteré předměty se nevešly do inventáře!"
    end

    if #messages > 0 then
        return true, table.concat(messages, "\n")
    else
        return false, "V tomto hrobě nic nebylo."
    end
end)

lib.callback.register("cayo_grave_robbing:failed", function(source, graveId)
    if GraveRobberyAttempts[graveId] == source then
        GraveRobberyAttempts[graveId] = nil
    end
    
    local graveData = checkAndGetInfo(source, graveId)
    if not graveData then return end

    reduceShovelDurability(source)


    if math.random(1, 100) <= Config.DispatchChanceFail then
        TriggerClientEvent("cd_dispatch:AddNotification", -1, {
            job_table = {"usa"}, 
            coords = graveData.coords,
            title = "Vykrádání hrobů",
            message = "Někdo vykrádá hroby na ostrově Cayo Perico!",
            flash = 0,
            unique_id = tostring(math.random(0000000,9999999)),
            sound = 1,
            blip = {
                sprite = 630,
                scale = 0.5,
                colour = 1,
                flashes = false,
                text = "Vykrádání hrobu",
                time = 5,
                radius = 0,
            }
        })
    end
end)

RegisterNetEvent("cayo_grave_robbing:resetRobberyStatus", function(graveId)
    if GraveRobberyAttempts[graveId] == source then
        GraveRobberyAttempts[graveId] = nil
    end
    if ActiveGraveRobberies[graveId] == source then
        ActiveGraveRobberies[graveId] = nil
    end
end)

AddEventHandler('playerDropped', function()
    local source = source
    
    for graveId, playerId in pairs(GraveRobberyAttempts) do
        if playerId == source then
            GraveRobberyAttempts[graveId] = nil
        end
    end
    
    for graveId, playerId in pairs(ActiveGraveRobberies) do
        if playerId == source then
            ActiveGraveRobberies[graveId] = nil
        end
    end
end)