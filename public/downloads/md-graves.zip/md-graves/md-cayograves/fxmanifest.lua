fx_version 'cerulean'
game 'gta5'

author 'MeDaaa'
version '1.0'

shared_script '@ox_lib/init.lua'
shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

dependencies {
    'es_extended',
    'ox_lib',
    'ox_target',
    'ox_inventory'
}

lua54 'yes'