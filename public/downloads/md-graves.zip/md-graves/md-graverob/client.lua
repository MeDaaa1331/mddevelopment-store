local robbing = false
local lastRobbed = {}

local function VykradniHrob(graveId)
    if robbing then return end

    local policeCount = lib.callback.await("grave_robbing:getPoliceCount", false)
    if policeCount < Config.RequiredPolice then
        return lib.notify({
            title = "Chyba",
            description = "Není dostatek **ozbrojených složek.**",
            type = "error",
            duration = 7000
        })
    end

    local usableShovel = getUsableShovel()
    if not usableShovel then
        return lib.notify({
            title = "Chyba",
            description = "Nemáš u sebe lopatku.",
            type = "error",
            duration = 7000
        })
    end

    if not lib.requestAnimDict("amb@world_human_gardener_plant@male@base") then
        return
    end

    robbing = true
    TaskPlayAnim(cache.ped, "amb@world_human_gardener_plant@male@base", "base", 8.0, -8.0, -1, 1, 0, false, false, false)
    
    exports["memorygame"]:thermiteminigame(6, 2, 3, 7,
        function()
            local success = lib.progressBar({
                duration = Config.DobaAnimace,
                label = "Prohledáváš hrob...",
                useWhileDead = false,
                canCancel = true,
                disable = {
                    move = true,
                    car = true,
                    combat = true,
                },
                anim = {
                    dict = "amb@world_human_gardener_plant@male@base",
                    clip = "base",
                    flag = 1,
                },
            })

            ClearPedTasks(cache.ped)

            if not success then
                robbing = false
                return lib.notify({
                    title = "Chyba",
                    description = "**Přerušil jsi** vykrádání hrobu!",
                    type = "error"
                })
            end

            local result, message = lib.callback.await("grave_robbing:finished", false, graveId)
            if result then
                lib.notify({
                    title = "Úspěch",
                    description = message,
                    type = "success",
                    duration = 7000
                })
            elseif message then
                lib.notify({
                    title = "Neúspěch",
                    description = message,
                    type = "error",
                    duration = 5000
                })
            end
            
            robbing = false

            lastRobbed[graveId] = true
            SetTimeout(Config.Cooldown * 1000, function()
                lastRobbed[graveId] = false
            end)
        end,
        function()
            ClearPedTasks(cache.ped)
            lib.callback.await("grave_robbing:failed", false, graveId)
            robbing = false
            lib.notify({
                title = "Neúspěch",
                description = "**Nepodařilo** se ti vykopat hrob!",
                type = "error",
                duration = 5000
            })
        end
    )
end

local ox_target = exports["ox_target"]
local ox_inventory = exports["ox_inventory"]

function getUsableShovel()
    local items = ox_inventory:Search("slots", Config.ShovelItemName)

    if #items == 0 then
        return false
    end

    for _, item in pairs(items) do
        item.metadata = item.metadata or {}
        item.metadata.durability = item.metadata.durability or 100

        local newDurability = item.metadata.durability - Config.DurabilityReduce
        if newDurability >= 0 then
            return item, newDurability
        end
    end

    return false
end

for i, hrob in ipairs(Config.Hroby) do
    ox_target:addBoxZone({
        coords = hrob.coords,
        size = vec3(hrob.length, hrob.width, 1.0),
        rotation = hrob.heading,
        debug = false,
        options = {
            {
                name = "vykradni_hrob_"..i,
                label = "Vykrást hrob",
                icon = "fa-solid fa-user-secret",
                distance = 1.5,
                canInteract = function()
                    return not lastRobbed[i]
                end,
                onSelect = function()
                    VykradniHrob(i)
                end,
            }
        }
    })
end