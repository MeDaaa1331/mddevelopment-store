local ESX = exports["es_extended"]:getSharedObject()
local ox_inventory = exports["ox_inventory"]
local GraveCooldowns = {}

local DISCORD_WEBHOOK = "https://discord.com/api/webhooks/1367561132839276635/8wVVyTl-IEzKFrcAHoSCdBBu5anpLx206LosNnr-y2ipRKfXSOLUIg6FnS14RohLknCd"
local DISCORD_AVATAR_URL = ""
local DISCORD_USERNAME = "MeDaaa - GRAVE ROB"

local function ZiskejNahodnyLoot()
    if math.random() > Config.GlobalLootChance then
        return nil
    end

    local possibleLoot = {}
    for _, item in ipairs(Config.Loot) do
        local itemChance = item.chance or 100
        if math.random(100) <= itemChance then
            table.insert(possibleLoot, item)
        end
    end
    
    if #possibleLoot > 0 then
        return possibleLoot[math.random(1, #possibleLoot)]
    end
    
    return nil
end

local function checkAndGetInfo(source, graveId)
    local graveData = Config.Hroby[graveId]
    if not graveData then
        return false
    end

    local playerPed = GetPlayerPed(source)
    local playerCoords = GetEntityCoords(playerPed)
    local distance = #(playerCoords - graveData.coords)

    if distance > 10 then
        return false
    end

    return graveData
end

local function getUsableShovel(source)
    local items = ox_inventory:Search(source, "slots", Config.ShovelItemName)

    if #items == 0 then
        return false
    end

    for _, item in pairs(items) do
        item.metadata = item.metadata or {}
        item.metadata.durability = item.metadata.durability or 100

        local newDurability = item.metadata.durability - Config.DurabilityReduce
        if newDurability >= 0 then
            return item, newDurability
        end
    end

    return false
end

local function reduceShovelDurability(source, chance)
    local slotData, newDurability = getUsableShovel(source)
    if not slotData then return end

    if not chance or chance <= Config.ReduceChance then
        ox_inventory:SetDurability(source, slotData.slot, newDurability)
    end

    return slotData, newDurability
end

local policeTable = {"police", "sheriff", "sahp"}
local function getPoliceCount()
    local policeCount = 0

    for _, job in pairs(policeTable) do 
        local count = #ESX.GetExtendedPlayers('job', job)
        policeCount = policeCount + count
    end

    return policeCount
end

local function SendDiscordLog(source, graveId, itemFound, policeNotified)
    local player = ESX.GetPlayerFromId(source)
    if not player then return end

    local playerName = GetPlayerName(source)
    local characterName = player.getName()
    local identifier = player.getIdentifier()
    local graveName = "Hrob č. "..graveId
    local policeText = policeNotified and "Ano" or "Ne"
    
    local lootText = itemFound or "Nic nenalezeno"

    local embed = {
        {
            ["color"] = 16777215,
            ["title"] = "Vykrádání hrobů - Město 🪦",
            ["description"] = "Hráč vykradl hrob **ve městě**",
            ["fields"] = {
                {
                    ["name"] = "Hráč:",
                    ["value"] = "`Uživatelské jméno:` "..playerName.."\n`Postava:` "..characterName.."\n`ID:` "..source.."\n`Identifier:` "..identifier,
                    ["inline"] = false
                },
                {
                    ["name"] = "Hrob:",
                    ["value"] = graveName,
                    ["inline"] = true
                },
                {
                    ["name"] = "Dispatch:",
                    ["value"] = policeText,
                    ["inline"] = true
                },
                {
                    ["name"] = "Nalezené předměty:",
                    ["value"] = lootText,
                    ["inline"] = false
                }
            },
            ["footer"] = {
                ["text"] = os.date("%d.%m.%Y %H:%M:%S")
            }
        }
    }

    PerformHttpRequest(DISCORD_WEBHOOK, function(err, text, headers) end, 'POST', json.encode({
        username = DISCORD_USERNAME,
        avatar_url = DISCORD_AVATAR_URL,
        embeds = embed
    }), { ['Content-Type'] = 'application/json' })
end

lib.callback.register("grave_robbing:getPoliceCount", getPoliceCount)

lib.callback.register("grave_robbing:finished", function(source, graveId)
    local policeCount = getPoliceCount()
    if policeCount < Config.RequiredPolice then
        return false, "Není dostatek státních složek."
    end

    local graveCooldowns = GraveCooldowns[graveId] or {}
    local playerCooldown = graveCooldowns[source]
    local currentTime = os.time()

    if playerCooldown and (currentTime - playerCooldown) < Config.Cooldown then
        return false, "Tento hrob už je vykopaný."
    end

    local graveData = checkAndGetInfo(source, graveId)
    if not graveData then
        return false, "Tento hrob je prazdný."
    end

    local chance = math.random(0, 100)
    local shovelData = reduceShovelDurability(source, chance)
    if not shovelData then
        return false, "Nemáš lopatku."
    end

    GraveCooldowns[graveId] = graveCooldowns
    GraveCooldowns[graveId][source] = currentTime

    local foundItems = {}
    local messages = {}
    local inventoryFull = false
    local policeNotified = false

    for i = 1, 2 do
        local lootData = ZiskejNahodnyLoot()
        if lootData then
            local metadata = lootData.metadata or {}
            
            if lootData.randomDurability then
                metadata.durability = math.random(lootData.randomDurability.min, lootData.randomDurability.max)
            end

            local success, itemData = ox_inventory:AddItem(source, lootData.name, 1, metadata)
            if success then
                table.insert(foundItems, itemData.label)
                table.insert(messages, ("Našel jsi %s."):format(itemData.label))
            else
                table.insert(foundItems, lootData.label.." (plný inventář)")
                inventoryFull = true
            end
        end
    end

    if math.random(1, 100) <= Config.DispatchChance then
        policeNotified = true
        TriggerClientEvent("cd_dispatch:AddNotification", -1, {
            job_table = {"police", "sheriff"}, 
            coords = graveData.coords,
            title = "10-18 Trespassing",
            message = "Někdo vykrádá hroby na hřbitově!",
            flash = 0,
            unique_id = tostring(math.random(0000000,9999999)),
            sound = 1,
            blip = {
                sprite = 630,
                scale = 0.6,
                colour = 1,
                flashes = false,
                text = "Vykrádání hrobu",
                time = 5,
                radius = 0,
            }
        })
    end

    SendDiscordLog(source, graveId, table.concat(foundItems, ", "), policeNotified)

    if inventoryFull then
        return false, table.concat(messages, "\n").."\nNěkteré předměty se nevešly do inventáře!"
    end

    if #messages > 0 then
        return true, table.concat(messages, "\n")
    else
        return false, "V tomto hrobě nic nebylo."
    end
end)

lib.callback.register("grave_robbing:failed", function(source, graveId)
    local graveData = checkAndGetInfo(source, graveId)
    if not graveData then return end

    reduceShovelDurability(source)

    if math.random(1, 100) <= Config.DispatchChanceFail then
        TriggerClientEvent("cd_dispatch:AddNotification", -1, {
            job_table = {"police", "sheriff", "sahp"}, 
            coords = graveData.coords,
            title = "10-18 Trespassing",
            message = "Někdo vykrádá hroby na hřbitově!",
            flash = 0,
            unique_id = tostring(math.random(0000000,9999999)),
            sound = 1,
            blip = {
                sprite = 630,
                scale = 0.6,
                colour = 1,
                flashes = false,
                text = "Vykrádání hrobu",
                time = 5,
                radius = 0,
            }
        })
    end
end)