fx_version 'cerulean'
game 'gta5'

author 'MeDaaa'
version '1.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

dependencies {
    'es_extended',
    'esx_license',
    'ox_inventory',
    'ox_target',
    'ox_lib'
}

lua54 'yes'