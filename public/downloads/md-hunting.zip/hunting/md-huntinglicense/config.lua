Config = {
    HuntingLicense = {
        Price = 10000,
        NPCModel = 'a_m_m_hillbilly_01',
        NPCLocation = vector4(-773.3073, 5598.6787, 32.6050, 170.7313),
        TargetLabel = 'Koupit lovecký průkaz',
        TargetIcon = 'fa-solid fa-id-card',
        Blip = {
            Enable = true,
            Sprite = 442,
            Color = 0,
            Scale = 0.6,
            Label = 'Lovecky prukaz'
        }
    }
}