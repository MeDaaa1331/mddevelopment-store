local ESX = exports['es_extended']:getSharedObject()
local initialized = true

function RegisterEvents()
    RegisterNetEvent('huntinglicense:buy', function()
        local src = source
        local xPlayer = ESX.GetPlayerFromId(src)
        if not xPlayer then
            return
        end

        local price = Config.HuntingLicense.Price

        TriggerEvent('esx_license:checkLicense', src, 'hunting', function(hasLicense)
            if hasLicense then
                TriggerClientEvent('ox_lib:notify', src, {
                    type = 'error',
                    title = 'Chyba',
                    description = 'Již **máš lovecký průkaz!**',
                    duration = 5000
                })
                return
            end

            if xPlayer.getMoney() >= price then
                xPlayer.removeMoney(price)

                TriggerEvent('esx_license:addLicense', src, 'hunting', function()
                    TriggerClientEvent('ox_lib:notify', src, {
                        type = 'success',
                        title = 'Úspěch',
                        description = 'Úspěšně jsi **zakoupil lovecký průkaz** za $'..price,
                        duration = 5000
                    })
                end)
            else
                TriggerClientEvent('ox_lib:notify', src, {
                    type = 'error',
                    title = 'Chyba',
                    description = '**Nemáš dostatek peněz!** Potřebuješ $'..price,
                    duration = 5000
                })
            end
        end)
    end)
end

RegisterEvents()