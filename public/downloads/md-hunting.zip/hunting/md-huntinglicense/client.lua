local ox_target = exports.ox_target
local ox_lib = exports.ox_lib

local function CreateLicenseNPC()
    local npcData = Config.HuntingLicense

    if not IsModelValid(npcData.NPCModel) then
        return
    end

    RequestModel(npcData.NPCModel)
    while not HasModelLoaded(npcData.NPCModel) do
        Wait(0)
    end

    local npc = CreatePed(4, npcData.NPCModel, npcData.NPCLocation.xyz, npcData.NPCLocation.w, false, true)
    if not DoesEntityExist(npc) then
        print('Nepodařilo se načíst NPC')
        return
    end

    FreezeEntityPosition(npc, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    print('NPC Načteno')

    ox_target:addLocalEntity(npc, {
        {
            name = 'buy_hunting_license',
            icon = npcData.TargetIcon,
            label = npcData.TargetLabel,
            distance = 2.5,
            onSelect = function()
                TriggerServerEvent('huntinglicense:buy')
            end
        }
    })

    if npcData.Blip.Enable then
        local blip = AddBlipForCoord(npcData.NPCLocation.xyz)
        SetBlipSprite(blip, npcData.Blip.Sprite)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, npcData.Blip.Scale)
        SetBlipColour(blip, npcData.Blip.Color)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(npcData.Blip.Label)
        EndTextCommandSetBlipName(blip)
    end
end

CreateThread(function()
    while not ox_target or not ox_lib do
        Wait(1000)
    end
    
    CreateLicenseNPC()
end)