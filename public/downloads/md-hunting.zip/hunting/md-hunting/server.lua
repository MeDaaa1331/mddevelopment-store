local processedAnimals = {}

RegisterNetEvent('esx_hunting:processAnimal', function(animalModel, netId)
    local src = source
    local animalData = Config.HuntableAnimals[animalModel]

    if not animalData then return end

    local playerPed = GetPlayerPed(src)
    local currentWeapon = GetSelectedPedWeapon(playerPed)
    if currentWeapon ~= GetHashKey('WEAPON_KNIFE') then
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Chyba',
            description = 'Musíš mít nůž v ruce!',
            type = 'error'
        })
        return
    end

    if processedAnimals[netId] then
        return
    end

    processedAnimals[netId] = true

    for _, reward in ipairs(animalData.rewards) do
        local amount = math.random(reward.amount[1], reward.amount[2])
        exports.ox_inventory:AddItem(src, reward.item, amount)
    end

    SetTimeout(1800000, function()
        processedAnimals[netId] = nil
    end)
end)