local animalsInProcess = {}
local processedAnimals = {}
local processingZone = nil

local animalModels = {}
for model, _ in pairs(Config.HuntableAnimals) do
    table.insert(animalModels, model)
end

local function isInHuntingZone(coords)
    local zoneCenter = Config.ProcessingLocation.coords
    local zoneRadius = Config.ProcessingLocation.radius
    return #(coords - zoneCenter) <= zoneRadius
end

local function spawnAnimals()
    if not Config.AnimalSpawning.enabled then return end

    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local animalsInZone = 0

    local allAnimals = GetGamePool('CPed')
    for _, animal in ipairs(allAnimals) do
        if not IsPedHuman(animal) then
            local animalCoords = GetEntityCoords(animal)
            if isInHuntingZone(animalCoords) then
                animalsInZone = animalsInZone + 1
            end
        end
    end

    if animalsInZone < Config.AnimalSpawning.maxAnimals then
        local animalsToSpawn = Config.AnimalSpawning.maxAnimals - animalsInZone
        for _ = 1, animalsToSpawn do
            local randomModel = animalModels[math.random(#animalModels)]
            
            local angle = math.random() * math.pi * 2
            local distanceFromPlayer = math.random(Config.AnimalSpawning.spawnDistanceMin, Config.AnimalSpawning.spawnDistanceMax)
            local spawnCoords = GetOffsetFromEntityInWorldCoords(
                playerPed,
                math.cos(angle) * distanceFromPlayer,
                math.sin(angle) * distanceFromPlayer,
                0.0
            )

            if isInHuntingZone(spawnCoords) then
                local _, groundZ = GetGroundZFor_3dCoord(spawnCoords.x, spawnCoords.y, spawnCoords.z, false)
                if groundZ then
                    spawnCoords = vector3(spawnCoords.x, spawnCoords.y, groundZ)
                    
                    RequestModel(randomModel)
                    while not HasModelLoaded(randomModel) do
                        Wait(10)
                    end
                    
                    local animal = CreatePed(28, randomModel, spawnCoords.x, spawnCoords.y, spawnCoords.z, 0.0, true, true)
                    SetEntityAsMissionEntity(animal, true, true)
                    SetModelAsNoLongerNeeded(randomModel)
                    
                    TaskWanderStandard(animal, 10.0, 10)
                    SetPedFleeAttributes(animal, 0, false)
                    SetPedRelationshipGroupHash(animal, GetHashKey('WILD_ANIMAL'))
                end
            end
        end
    end
end

CreateThread(function()
    while true do
        Wait(Config.AnimalSpawning.spawnInterval)
        if isInHuntingZone(GetEntityCoords(PlayerPedId())) then
            spawnAnimals()
        end
    end
end)

local function processAnimal(entity)
    local playerPed = PlayerPedId()
    local animalModel = GetEntityModel(entity)
    local animalData = Config.HuntableAnimals[animalModel]
    local entityId = NetworkGetNetworkIdFromEntity(entity)

    if not animalData then
        exports.ox_lib:notify({
            title = Config.Notifications.errorTitle,
            description = Config.Notifications.noAnimal,
            type = 'error'
        })
        return
    end

    if processedAnimals[entityId] then
        exports.ox_lib:notify({
            title = Config.Notifications.errorTitle,
            description = Config.Notifications.alreadyProcessed,
            type = 'error'
        })
        return
    end

    if animalsInProcess[entityId] then
        exports.ox_lib:notify({
            title = Config.Notifications.errorTitle,
            description = Config.Notifications.alreadyProcessing,
            type = 'error'
        })
        return
    end

    if #(GetEntityCoords(playerPed) - Config.ProcessingLocation.coords) > Config.ProcessingLocation.radius then
        exports.ox_lib:notify({
            title = Config.Notifications.errorTitle,
            description = Config.Notifications.wrongLocation,
            type = 'error'
        })
        return
    end

    local currentWeapon = GetSelectedPedWeapon(playerPed)
    if currentWeapon ~= GetHashKey('WEAPON_KNIFE') then
        exports.ox_lib:notify({
            title = Config.Notifications.errorTitle,
            description = Config.Notifications.wrongItem,
            type = 'error'
        })
        return
    end

    animalsInProcess[entityId] = true

    if exports.ox_lib:progressBar({
        duration = animalData.processingTime,
        label = Config.Notifications.processing,
        useWhileDead = false,
        canCancel = true,
        disable = {
            move = true,
            car = true,
            combat = true
        },
        anim = {
            scenario = 'WORLD_HUMAN_GARDENER_PLANT'
        }
    }) then
        TriggerServerEvent('esx_hunting:processAnimal', animalModel, entityId)
        
        processedAnimals[entityId] = true
        animalsInProcess[entityId] = nil

        exports.ox_lib:notify({
            title = Config.Notifications.successTitle,
            description = Config.Notifications.processed,
            type = 'success'
        })

        SetTimeout(30000, function()
            local entity = NetworkGetEntityFromNetworkId(entityId)
            if DoesEntityExist(entity) then
                DeleteEntity(entity)
            end
            processedAnimals[entityId] = nil
            animalsInProcess[entityId] = nil
        end)
    else
        animalsInProcess[entityId] = nil
        exports.ox_lib:notify({
            title = Config.Notifications.errorTitle,
            description = "Zpracování zrušeno",
            type = 'error'
        })
    end
end

CreateThread(function()
    while not exports.ox_lib or not exports.ox_target or not exports.ox_inventory do
        Wait(100)
    end

    if Config.ProcessingLocation.blip.enable then
        if Config.ProcessingLocation.showRadius then
            local blip = AddBlipForRadius(Config.ProcessingLocation.coords.x, Config.ProcessingLocation.coords.y, Config.ProcessingLocation.coords.z, Config.ProcessingLocation.radius)
            SetBlipHighDetail(blip, true)
            SetBlipColour(blip, 1)
            SetBlipAlpha(blip, 128)
            SetBlipAsShortRange(blip, true)
        end

        local processingBlip = AddBlipForCoord(Config.ProcessingLocation.coords)
        SetBlipSprite(processingBlip, Config.ProcessingLocation.blip.sprite)
        SetBlipDisplay(processingBlip, 4)
        SetBlipScale(processingBlip, Config.ProcessingLocation.blip.scale)
        SetBlipColour(processingBlip, Config.ProcessingLocation.blip.color)
        SetBlipAsShortRange(processingBlip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(Config.ProcessingLocation.blip.label)
        EndTextCommandSetBlipName(processingBlip)
    end

    exports.ox_target:addModel({
        'a_c_boar', 'a_c_deer', 'a_c_coyote'
    }, {
        {
            name = 'process_animal',
            icon = 'fa-solid fa-hand',
            label = 'Zpracovat zvíře',
            distance = 2.0,
            onSelect = function(data)
                if not DoesEntityExist(data.entity) then return end
                processAnimal(data.entity)
            end,
            canInteract = function(entity)
                if not entity or not DoesEntityExist(entity) then return false end
                if not IsEntityDead(entity) then return false end
                
                local model = GetEntityModel(entity)
                local entityId = NetworkGetNetworkIdFromEntity(entity)
                local playerPed = PlayerPedId()
                local hasKnife = GetSelectedPedWeapon(playerPed) == GetHashKey('WEAPON_KNIFE')
                
                return Config.HuntableAnimals[model] and 
                       not processedAnimals[entityId] and 
                       not animalsInProcess[entityId] and
                       hasKnife
            end
        }
    })

    exports.ox_target:addBoxZone({
        coords = Config.ProcessingLocation.coords,
        size = vector3(Config.ProcessingLocation.radius * 2, Config.ProcessingLocation.radius * 2, 3.0),
        rotation = 0,
        debug = Config.Debug,
        options = {
            {
                name = 'processing_zone',
                icon = 'fa-solid fa-circle-info',
                label = Config.Notifications.enterZone,
                onSelect = function()
                    exports.ox_lib:notify({
                        title = Config.ProcessingLocation.blip.label,
                        description = Config.Notifications.enterZone,
                        type = 'inform'
                    })
                end
            }
        }
    })
end)