Config = {}

Config.ProcessingLocation = {
    coords = vector3(-1160.7737, 4285.9121, 83.0410),
    radius = 550.0,
    blip = {
        enable = true,
        sprite = 141,
        color = 1,
        scale = 0.7,
        label = "Lovecká zona"
    },
    showRadius = true
}

Config.HuntableAnimals = {
    [`a_c_boar`] = {
        label = "Divoké prase",
        requiredItem = "WEAPON_KNIFE",
        rewards = {
            { item = "raw_meat", amount = {1, 4} },
            { item = "zvireci_kuze", amount = {1, 2} },
        },
        processingTime = 10000
    },
    [`a_c_deer`] = {
        label = "Jelen",
        requiredItem = "WEAPON_KNIFE",
        rewards = {
            { item = "raw_meat", amount = {2, 5} },
            { item = "skin_deer_good", amount = {2, 3} },
            { item = "deer_horn", amount = {1, 2} }
        },
        processingTime = 15000
    },
    [`a_c_coyote`] = {
        label = "Kojot",
        requiredItem = "WEAPON_KNIFE",
        rewards = {
            { item = "raw_meat", amount = {1, 3} },
            { item = "zvireci_kuze", amount = {1, 2} }
        },
        processingTime = 9000
    }
}

Config.Notifications = {
    successTitle = "Úspěch",
    errorTitle = "Chyba",
    noAnimal = "**Nenalezeno** zvíře ke zppracování.",
    wrongItem = "Nemáš **nůž** v ruce!",
    wrongLocation = "Zvěř můžeš zpracovávat pouze na **určeném místě!**",
    processing = "Zpracováváš zvěř...",
    processed = "Úspěšně jsi **zpracoval zvěř!**",
    enterZone = "Vstoupil jsi do **lovecké zony!**",
    exitZone = "Opustil jsi **loveckou zonu!**",
    alreadyProcessing = "Někdo již toto zvíře **zpracovává!**",
    alreadyProcessed = "Toto zvíře již bylo **zpracováno!**"
}

Config.AnimalSpawning = {
    enabled = true,
    maxAnimals = 25,
    spawnInterval = 45000,
    spawnDistanceMin = 10.0,
    spawnDistanceMax = 500.0
}

Config.Debug = false