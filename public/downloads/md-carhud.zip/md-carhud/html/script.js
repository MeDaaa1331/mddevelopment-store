$(document).ready(function() {
    window.addEventListener('message', function(event) {
        let data = event.data;

        if (data.type === "ui") {
            if (data.display) {
                $("#container").css("opacity", "1");
            } else {
                $("#container").css("opacity", "0");
            }
        }

        if (data.type === "update") {
            let speedStr = data.speed.toString().padStart(3, '0');
            $("#speed").text(speedStr);

            $("#gear").text(data.gear);

            let rpmPercent = data.rpm * 100;
            let bar = $("#rpm-bar");
            bar.css("width", rpmPercent + "%");

            if (data.rpm >= data.redZone) {
                bar.addClass("redline");
            } else {
                bar.removeClass("redline");
            }

            $("#fuel-text").text(Math.round(data.fuel) + "L");
            if (data.fuel < 20) {
                $(".fuel-info").css("color", "#ff3333");
            } else {
                $(".fuel-info").css("color", "#ccc");
            }

            let engineHealth = data.engine;
            let engineBar = $("#engine-health-bar");
            engineBar.css("width", engineHealth + "%");

            let engineColor = "#00ff00";
            if (engineHealth < 80) engineColor = "#ffff00";
            if (engineHealth < 40) engineColor = "#ff3333";
            
            engineBar.css("background", engineColor)
                     .css("box-shadow", `0 0 5px ${engineColor}`);

            $("#lights-icon").removeClass("active-green");
            $("#highbeam-icon").removeClass("active-blue");

            if (data.lights === 1) {
                $("#lights-icon").addClass("active-green");
            } else if (data.lights === 2) {
                $("#lights-icon").addClass("active-green");
                $("#highbeam-icon").addClass("active-blue");
            }

            if (data.handbrake) {
                $("#handbrake-icon").addClass("active-red");
            } else {
                $("#handbrake-icon").removeClass("active-red");
            }

            if (data.abs) {
                $("#abs-icon").addClass("active-amber");
            } else {
                $("#abs-icon").removeClass("active-amber");
            }

            if (data.traction) {
                $("#traction-icon").addClass("active-amber");
            } else {
                $("#traction-icon").removeClass("active-amber");
            }
        }
    });
});