local bleedingThreshold = 150
local bleedDamage = 3
local bleedInterval = 5000
local bandageItem = 'skrtidlo'
local bandageCooldown = 300000

local isBleeding = false
local isBandageActive = false
local lastDamageWasWeapon = false

local function StartBandageAnimation()
    local playerPed = PlayerPedId()
    RequestAnimDict("amb@world_human_clipboard@male@idle_a")
    while not HasAnimDictLoaded("amb@world_human_clipboard@male@idle_a") do
        Wait(10)
    end
    
    TaskPlayAnim(playerPed, "amb@world_human_clipboard@male@idle_a", "idle_c", 8.0, -8.0, -1, 49, 0, false, false, false)
    
    local prop = CreateObject(GetHashKey('prop_ld_health_pack'), 0, 0, 0, true, true, true)
    AttachEntityToEntity(prop, playerPed, GetPedBoneIndex(playerPed, 60309), 0.1, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    
    return prop
end

local function StopBandageAnimation(prop)
    local playerPed = PlayerPedId()
    StopAnimTask(playerPed, "amb@world_human_clipboard@male@idle_a", "idle_c", 1.0)
    RemoveAnimDict("amb@world_human_clipboard@male@idle_a")
    
    if DoesEntityExist(prop) then
        DeleteEntity(prop)
    end
end

local function StartBleedingEffect()
    StartScreenEffect("PPOrange", 0, true)
end

local function StopBleedingEffect()
    StopScreenEffect("PPOrange")
end

local function CheckWeaponDamage()
    local playerPed = PlayerPedId()
    
    local weaponDamage = HasEntityBeenDamagedByWeapon(playerPed, 0, 2)
    
    local _, weaponHash = GetPedLastDamageBone(playerPed)
    
    local blacklistedWeapons = {
        [GetHashKey("WEAPON_UNARMED")] = true,
        [GetHashKey("WEAPON_FALL")] = true,
        [GetHashKey("WEAPON_RAMMED_BY_CAR")] = true,
        [GetHashKey("WEAPON_RUN_OVER_BY_CAR")] = true
    }
    
    return weaponDamage and weaponHash ~= 0 and not blacklistedWeapons[weaponHash]
end

CreateThread(function()
    local lastHealth = GetEntityHealth(PlayerPedId())
    
    while true do
        Wait(100)
        
        local playerPed = PlayerPedId()
        local currentHealth = GetEntityHealth(playerPed)
        
        if currentHealth < lastHealth then
            lastDamageWasWeapon = CheckWeaponDamage()
        end
        
        lastHealth = currentHealth
        
        if currentHealth > bleedingThreshold then
            lastDamageWasWeapon = false
        end
    end
end)

function StopBleeding()
    if not isBleeding then return end
    isBleeding = false
    StopBleedingEffect()
end

local function StartBleeding(playerId)
    if isBleeding or isBandageActive then return end
    isBleeding = true
    StartBleedingEffect()

    CreateThread(function()
        while isBleeding do
            local playerPed = GetPlayerPed(playerId)
            local currentHealth = GetEntityHealth(playerPed)

            if currentHealth <= bleedingThreshold then
                SetEntityHealth(playerPed, currentHealth - bleedDamage)
            end

            if GetEntityHealth(playerPed) <= 0 then
                StopBleeding()
                break
            end

            Wait(bleedInterval)
        end
    end)
end

local function StartBandageCooldown(playerId)
    isBandageActive = true
    Wait(bandageCooldown)
    isBandageActive = false

    local playerPed = GetPlayerPed(playerId)
    local currentHealth = GetEntityHealth(playerPed)
    if currentHealth <= bleedingThreshold then
        StartBleeding(playerId)
    end
end

CreateThread(function()
    while true do
        Wait(1000)

        local playerId = PlayerId()
        local playerPed = GetPlayerPed(playerId)
        local currentHealth = GetEntityHealth(playerPed)
        local maxHealth = GetEntityMaxHealth(playerPed)
        local healthPercent = (currentHealth/maxHealth) * 100

        if currentHealth <= bleedingThreshold and not isBleeding and not isBandageActive and lastDamageWasWeapon then
            StartBleeding(playerId)
            lib.notify({
                title = 'Krvácení',
                description = '**Začal jsi krvácet!**',
                type = 'error',
                duration = 5000
            })
            lib.notify({
                title = 'Krvácení',
                description = 'Použij **škrtidlo** pro zastavení krvácení!',
                duration = 8000
            })
        end

        if currentHealth > bleedingThreshold and isBleeding then
            StopBleeding()
            lib.notify({
                title = 'Úspěch',
                description = 'Přestal jsi krvácet!',
                type = 'success'
            })
        end
    end
end)

RegisterNetEvent("md-bleeding:stop", function()
    local prop = StartBandageAnimation()
    
    if lib.progressBar({
        duration = 6500,
        label = 'Zaškrcuješ ránu...',
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            move = false,
            combat = true
        },

    }) then
        StopBleeding()
        lib.notify({
            title = 'Úspěch',
            description = 'Krvácení bylo na **5 minut** zastaveno!',
            type = 'success',
            duration = 7000
        })
        
        local playerServerId = GetPlayerServerId(PlayerId())
        TriggerServerEvent('md-bleeding:removeBandage', playerServerId)

        local playerId = PlayerId()
        CreateThread(function()
            StartBandageCooldown(playerId)
        end)
    else
        lib.notify({
            title = 'Chyba',
            description = 'Přerušil jsi zaškrcování!',
            type = 'error'
        })
    end
    
    StopBandageAnimation(prop)
end)