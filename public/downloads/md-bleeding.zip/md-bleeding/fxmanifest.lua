fx_version 'cerulean'
game 'gta5'

author 'MeDaaa'

dependencies {
    'ox_inventory',
}

client_scripts {
    'client.lua',
}

server_scripts {
    'server.lua',
}

shared_script '@ox_lib/init.lua'

lua54 'yes'