RegisterNetEvent('md-bleeding:removeBandage', function(playerId)
    exports.ox_inventory:RemoveItem(playerId, 'skrtidlo', 1)
end)